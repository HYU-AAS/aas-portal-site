-- mist_dryer, read-only role dryer_reader
SELECT session_id,seq,batch_id,observed_at,ingested_at,phase,progress,
       inlet_pv,inlet_sv,outlet_pv,outlet_sv,exhaust_pv,exhaust_sv,alarm,quality
FROM dryer_twin.telemetry ORDER BY observed_at DESC LIMIT 50;

SELECT session_id,batch_id,started_at,completed_at,duration_sim_seconds
FROM dryer_twin.batch_runs WHERE completed_at IS NOT NULL ORDER BY completed_at DESC LIMIT 20;

-- Change selected to a specific session_id and batch_id for repeatable analysis.
WITH selected AS (
    SELECT session_id,batch_id FROM dryer_twin.batch_runs
    WHERE completed_at IS NOT NULL ORDER BY completed_at DESC LIMIT 1
)
SELECT observed_at AS utc,sim_seconds,'temperature' AS kind,
       jsonb_build_object('phase',phase,'inlet_pv',inlet_pv,'outlet_pv',outlet_pv) AS detail
FROM dryer_twin.telemetry JOIN selected USING(session_id,batch_id)
UNION ALL
SELECT observed_at,sim_seconds,kind,detail FROM dryer_twin.process_events JOIN selected USING(session_id,batch_id)
UNION ALL
SELECT calculated_at,sim_to,kpi,jsonb_build_object('key',aggregation_key,'status',status,'value',value,'unit',unit)
FROM dryer_twin.kpi_results JOIN selected USING(session_id,batch_id)
ORDER BY utc;

SELECT o.session_id,o.seq,m.observed_at,o.applied_at,o.covered_at,o.attempts,o.last_error,
       extract(epoch FROM o.applied_at-m.observed_at) AS observed_to_aas_s
FROM dryer_twin.aas_outbox o JOIN dryer_twin.messages m USING(session_id,seq)
JOIN dryer_twin.active_session a ON a.session_id=o.session_id ORDER BY o.seq DESC LIMIT 25;
