#!/bin/sh
set -eu
psql -v ON_ERROR_STOP=1 --username "$POSTGRES_USER" --dbname "$POSTGRES_DB" -v reader="$READER_PASSWORD" <<'SQL'
CREATE DATABASE dryer_basyx;
CREATE ROLE dryer_reader LOGIN PASSWORD :'reader';
REVOKE ALL ON DATABASE dryer_basyx FROM PUBLIC;
GRANT CONNECT ON DATABASE mist_dryer TO dryer_reader;
ALTER ROLE dryer_reader SET default_transaction_read_only = on;
SQL
