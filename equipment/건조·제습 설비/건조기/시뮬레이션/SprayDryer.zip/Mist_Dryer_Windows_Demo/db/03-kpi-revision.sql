ALTER TABLE dryer_twin.kpi_results ADD COLUMN IF NOT EXISTS trigger_seq bigint;
CREATE INDEX IF NOT EXISTS kpi_trigger ON dryer_twin.kpi_results (session_id,trigger_seq);

