CREATE SCHEMA IF NOT EXISTS dryer_twin;
SET search_path TO dryer_twin, public;

CREATE TABLE IF NOT EXISTS sessions (
    session_id uuid PRIMARY KEY,
    equipment_id text NOT NULL,
    source text NOT NULL CHECK (source IN ('isaac_sim','mock')),
    started_at timestamptz NOT NULL,
    ended_at timestamptz,
    expected_seconds double precision NOT NULL,
    last_seq bigint NOT NULL,
    last_sim_seconds double precision NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS active_session (
    equipment_id text PRIMARY KEY,
    session_id uuid NOT NULL REFERENCES sessions
);
CREATE TABLE IF NOT EXISTS messages (
    session_id uuid REFERENCES sessions,
    seq bigint,
    observed_at timestamptz NOT NULL,
    ingested_at timestamptz NOT NULL DEFAULT clock_timestamp(),
    sim_seconds double precision NOT NULL,
    batch_id text,
    kind text NOT NULL,
    phase text NOT NULL,
    progress double precision NOT NULL,
    payload jsonb NOT NULL,
    PRIMARY KEY (session_id, seq)
);
CREATE TABLE IF NOT EXISTS telemetry (
    session_id uuid,
    seq bigint,
    batch_id text NOT NULL,
    observed_at timestamptz NOT NULL,
    ingested_at timestamptz NOT NULL DEFAULT clock_timestamp(),
    sim_seconds double precision NOT NULL,
    phase text NOT NULL,
    progress double precision NOT NULL,
    inlet_pv double precision, inlet_sv double precision,
    inlet_high double precision, inlet_low double precision,
    outlet_pv double precision, outlet_sv double precision,
    outlet_high double precision, outlet_low double precision,
    chamber_temp double precision, moisture double precision,
    exhaust_pv double precision, exhaust_sv double precision,
    operating boolean, heater1 boolean, heater2 boolean, heater3 boolean, scr boolean,
    alarm boolean NOT NULL, quality jsonb NOT NULL, values jsonb NOT NULL,
    PRIMARY KEY (session_id, seq),
    FOREIGN KEY (session_id, seq) REFERENCES messages
);
CREATE TABLE IF NOT EXISTS batch_runs (
    session_id uuid REFERENCES sessions, batch_id text,
    started_at timestamptz NOT NULL, started_sim_seconds double precision NOT NULL,
    completed_at timestamptz, completed_sim_seconds double precision,
    duration_sim_seconds double precision,
    PRIMARY KEY (session_id, batch_id)
);
CREATE TABLE IF NOT EXISTS process_events (
    session_id uuid, seq bigint, batch_id text, observed_at timestamptz NOT NULL,
    sim_seconds double precision NOT NULL, kind text NOT NULL, phase text NOT NULL, detail jsonb NOT NULL,
    PRIMARY KEY (session_id, seq), FOREIGN KEY (session_id, seq) REFERENCES messages
);
CREATE TABLE IF NOT EXISTS kpi_results (
    session_id uuid REFERENCES sessions, aggregation_key text, kpi text,
    batch_id text NOT NULL, period text NOT NULL,
    sim_from double precision NOT NULL, sim_to double precision NOT NULL,
    calculated_at timestamptz NOT NULL DEFAULT clock_timestamp(),
    value double precision, unit text NOT NULL, status text NOT NULL,
    inputs jsonb NOT NULL, input_source text NOT NULL,
    PRIMARY KEY (session_id, aggregation_key, kpi)
);
CREATE TABLE IF NOT EXISTS aas_outbox (
    session_id uuid, seq bigint, payload jsonb NOT NULL,
    created_at timestamptz NOT NULL DEFAULT clock_timestamp(),
    applied_at timestamptz, covered_at timestamptz,
    attempts integer NOT NULL DEFAULT 0, last_error text,
    PRIMARY KEY (session_id, seq), FOREIGN KEY (session_id, seq) REFERENCES messages
);
CREATE INDEX IF NOT EXISTS telemetry_latest ON telemetry (session_id, observed_at DESC);
CREATE INDEX IF NOT EXISTS telemetry_batch ON telemetry (session_id, batch_id, seq);
CREATE INDEX IF NOT EXISTS batches_latest ON batch_runs (session_id, completed_at DESC);
CREATE INDEX IF NOT EXISTS events_latest ON process_events (session_id, observed_at DESC);
CREATE INDEX IF NOT EXISTS kpi_latest ON kpi_results (session_id, calculated_at DESC);
CREATE INDEX IF NOT EXISTS outbox_pending ON aas_outbox (session_id, seq) WHERE covered_at IS NULL;
GRANT USAGE ON SCHEMA dryer_twin TO dryer_reader;
GRANT SELECT ON ALL TABLES IN SCHEMA dryer_twin TO dryer_reader;
ALTER DEFAULT PRIVILEGES IN SCHEMA dryer_twin GRANT SELECT ON TABLES TO dryer_reader;
