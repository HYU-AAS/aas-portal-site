"""Import the Mist Dryer instance once and expose the live collection on BaSyx Java."""
import argparse
import json
import os
from pathlib import Path
import sys
import time
from urllib.error import HTTPError, URLError

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "bridge"))
from basyx import BaSyx, KPI_MAPPING_MODEL, KPI_RECORD, RUNTIME, encoded, fields, runtime_collection


def exists(api, path):
    try:
        api.call(path)
        return True
    except HTTPError as error:
        if error.code == 404:
            return False
        raise


def register(api, registry, resource, item, external, interface):
    path = f"/{resource}-descriptors"
    identifier = path + "/" + encoded(item["id"])
    properties = {key: item[key] for key in ("id", "idShort", "description", "displayName", "administration", "semanticId")
                  if key in item}
    if resource == "shell":
        asset = item["assetInformation"]
        properties.update({key: asset[key] for key in ("assetKind", "globalAssetId", "assetType") if key in asset})
    properties["endpoints"] = [{"interface": interface, "protocolInformation": {
        "href": external + ("/shells/" if resource == "shell" else "/submodels/") + encoded(item["id"]),
        "endpointProtocol": external.split(":", 1)[0]}}]
    api.base = registry
    if exists(api, identifier):
        current = api.call(identifier)
        if current.get("endpoints") != properties["endpoints"]:
            api.call(identifier, "PUT", properties)
    else:
        api.call(path, "POST", properties)


def sync_kpi_schema(api):
    mapping_path = api.sm(KPI_MAPPING_MODEL) + "/submodel-elements/MappingConfigurations"
    desired = api.locate(KPI_MAPPING_MODEL, "MappingConfigurations")
    live = api.call(mapping_path)

    # Migrate the old workbook aliases without comparing user-editable Lua blobs.
    legacy = {"UnitsPerHour": "APT", "TactTimeVariance": "ActualBatchDuration",
              "WIPQuantity": "OpeningWIPQuantity", "OverallEquipmentEffectiveness": "APT",
              "AvailabilityRate": "APT", "PerformanceEfficiency": "APT",
              "MeanTimeToRepair": "RepairedFailureCount"}
    templates = {spec["name"]: (spec, entry)
                 for spec, entry in zip(api.catalog["kpis"], desired["value"], strict=True)}
    changed = []
    for index, entry in enumerate(live["value"]):
        mapping = fields(entry)
        sinks = mapping.get("Sinks", {}).get("value", [])
        if len(sinks) != 1:
            continue
        name = fields(sinks[0]).get("SinkId", {}).get("value")
        sources = {fields(item).get("SourceId", {}).get("value") for item in mapping.get("Sources", {}).get("value", [])}
        if name in legacy and legacy[name] in sources:
            spec, template = templates[name]
            changed.append(spec)
            live["value"][index] = template
    if not changed:
        return
    input_fields = {key for spec in changed for key, item in spec["inputs"].items()
                    if item["path"].startswith("TimeSeries." + KPI_RECORD + ".")}
    result_fields = {spec["name"] for spec in changed}
    ts_path = api.sm("TimeSeries") + "/submodel-elements/"
    target_record = api.locate("TimeSeries", KPI_RECORD)
    managed_fields = input_fields | result_fields
    concept_ids = {item["semanticId"]["keys"][0]["value"] for item in target_record["value"]
                   if item["idShort"] in managed_fields}
    baseline = json.loads((ROOT / "aas/environment.json").read_text(encoding="utf-8"))
    for cd in baseline["conceptDescriptions"]:
        if cd["id"] not in concept_ids:
            continue
        path = "/concept-descriptions/" + encoded(cd["id"])
        if exists(api, path):
            api.call(path, "PUT", cd)
        else:
            api.call("/concept-descriptions", "POST", cd)
    for record_path in ("Metadata.Record", KPI_RECORD):
        current = api.call(ts_path + record_path)
        current_fields = fields(current)
        for item in api.locate("TimeSeries", record_path)["value"]:
            key = item["idShort"]
            if key in managed_fields or key.removesuffix("Status") in result_fields:
                updated = dict(item)
                current_fields[key] = {**updated, **current_fields.get(key, {})}
        current["value"] = list(current_fields.values())
        api.call(ts_path + record_path, "PUT", current)
    api.call(mapping_path, "PUT", live)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--aas", default=os.environ.get("AAS_URL", "http://aas-env:8081"))
    parser.add_argument("--external", default=os.environ.get("AAS_EXTERNAL_URL"))
    parser.add_argument("--aas-registry", default=os.environ.get("AAS_REGISTRY_URL"))
    parser.add_argument("--sm-registry", default=os.environ.get("SM_REGISTRY_URL"))
    args = parser.parse_args()
    catalog = json.loads((ROOT / "aas/runtime.json").read_text(encoding="utf-8"))
    api = BaSyx(ROOT, {"AAS_URL": args.aas}, catalog)
    until = time.monotonic() + 60
    while True:
        try:
            api.call("/description")
            break
        except URLError:
            if time.monotonic() >= until:
                raise
            time.sleep(1)
    resources = ["/shells/" + encoded(catalog["shell"]), *(api.sm(name) for name in catalog["submodels"])]
    present = [exists(api, path) for path in resources]
    if not any(present):
        archive = ROOT / "aas/Mist_Dryer_DRYER-SIM-01.aasx"
        boundary = "mist-dryer-import-5a9b2e"
        body = (f'--{boundary}\r\nContent-Disposition: form-data; name="file"; filename="{archive.name}"\r\n'
                "Content-Type: application/octet-stream\r\n\r\n").encode()
        api.call("/upload", "POST", body + archive.read_bytes() + f"\r\n--{boundary}--\r\n".encode(),
                 f"multipart/form-data; boundary={boundary}", timeout=45)
        present = [exists(api, path) for path in resources]
    if not all(present):
        raise RuntimeError("Mist Dryer shell or submodels are missing; inspect the partial import before retrying.")
    sync_kpi_schema(api)
    elements = api.sm("OperationalData") + "/submodel-elements"
    if not exists(api, f"{elements}/{RUNTIME}"):
        api.call(elements, "POST", runtime_collection({}))
    if args.aas_registry:
        shell = api.call(resources[0])
        register(api, args.aas_registry, "shell", shell, args.external or args.aas, "AAS-3.0")
    if args.sm_registry:
        for path in resources[1:]:
            api.base = args.aas
            model = api.call(path)
            register(api, args.sm_registry, "submodel", model, args.external or args.aas, "SUBMODEL-3.0")
    print("Mist Dryer AAS, eight submodels and TwinRuntime ready.")


if __name__ == "__main__":
    main()
