# 분무건조기 디지털 트윈 실행 가이드

이 패키지에는 실행용 AASX, Isaac Sim 분무건조기 USD와 애니메이션, BaSyx·PostgreSQL·Grafana 설정, 웹 3D 화면이 들어 있습니다. Windows 64비트에서 실행합니다. 시연 온도와 운전 신호는 수집 사양에 맞춘 모의값입니다.

## 준비

- [Python 3.12 64비트](https://www.python.org/downloads/windows/)를 설치합니다. PowerShell에서 `py -3.12 --version`으로 확인합니다.
- [Docker Desktop](https://docs.docker.com/desktop/setup/install/windows-install/)을 시작하고 Linux 컨테이너 모드에서 `docker compose version`을 확인합니다. 최초 실행 시 이미지를 내려받습니다.
- 3D 애니메이션을 돌리려면 [NVIDIA Isaac Sim 6.2 Workstation](https://docs.isaacsim.omniverse.nvidia.com/6.2.0/installation/install_workstation.html)을 설치합니다. `python.bat`가 있는 폴더를 아래 예시의 `C:\isaacsim` 자리에 지정합니다.

## Isaac Sim과 함께 실행

다운로드한 ZIP을 압축 해제하고 `Mist_Dryer_Windows_Demo` 폴더에서 PowerShell을 엽니다.

```powershell
.\scripts\Initialize-DryerTwin.ps1 -IsaacRoot 'C:\isaacsim'
.\scripts\Start-DryerTwin.ps1 -Batches 2
```

초기화는 Python 환경과 로컬 암호를 만듭니다. `py`가 설치된 Python을 찾지 못하면 초기화 명령에 `-Python312 'C:\실제경로\python.exe'`를 추가합니다. 초기화한 뒤 Isaac Sim을 다른 경로에 설치했다면 `.env`의 `ISAAC_ROOT`를 변경합니다. PowerShell이 다운로드한 스크립트를 차단하면 ZIP 파일의 속성에서 **차단 해제**를 선택한 뒤 다시 풉니다.

Isaac Sim 창에서 예열·연속 분무·냉각·완료를 볼 수 있습니다. 첫 실행은 로딩과 컨테이너 준비가 필요합니다. 시연은 60배속으로 진행하고 배치 2개를 처리한 뒤 냉각합니다. 대시보드에서 새 `isaac_sim` 세션을 선택하고 최근 15분을 조회합니다.

## Isaac Sim 없이 연동 확인

```powershell
.\scripts\Initialize-DryerTwin.ps1
.\scripts\Start-DryerTwin.ps1 -ServicesOnly
.\.venv\Scripts\python.exe .\isaac\mock.py
```

기본 설정의 mock도 같은 연속 분무 모델로 두 배치를 실행합니다. Grafana에서는 새 `mock` 세션을 선택합니다.

| 화면 | 주소 |
|---|---|
| BaSyx AAS 조회 | [AAS Viewer](http://127.0.0.1:3015/aasviewer) |
| BaSyx AAS 편집 | [SM Editor](http://127.0.0.1:3015/smeditor) · [Swagger](http://127.0.0.1:8184/swagger-ui/index.html) |
| 운전과 KPI | [Grafana 대시보드](http://127.0.0.1:3014/d/mist-dryer/mist-dryer) |
| 수집 신호 | [Grafana 수집 신호](http://127.0.0.1:3014/d/mist-dryer-signals) |
| 3D 조회와 다시 보기 | [브라우저 3D](http://127.0.0.1:8092/) |

## AAS 경로와 확인 예시

- **입구 온도**는 BaSyx `OperationalData.AirHandlingOperation.AirConditions.InletAirTemperatureActual`에서 최신값을 봅니다. 추세는 Grafana 수집 신호에서 확인합니다.
- **가동률**은 `TimeSeries.Segments.InternalSegmentKPI.Records.KPIRecord.OperatingTime`의 실제 모의 운전 시간과 `ProcessVariablesForManufacturingKPICalculation.PlannedBusyTime.currentValue`의 계획 부하 시간으로 계산합니다. 정상 2배치 시연은 3,600초 ÷ 3,600초 × 100 = 100%입니다.
- **산식**은 `AssetInterfacesMappingConfiguration.MappingConfigurations`의 지표별 `Transformation` Blob에 있습니다. 브리지는 집계 시 BaSyx의 입력 속성과 Blob을 읽고 결과를 `KPIRecord`와 PostgreSQL에 반영합니다. Grafana는 PostgreSQL을 조회합니다.

`aas/Mist_Dryer_DRYER-SIM-01.aasx`는 다른 AAS 뷰어에서 열거나 BaSyx에 가져올 수 있습니다. 패키지의 시작 스크립트는 실행용 AASX를 BaSyx에 초기 등록합니다. `isaac/assets/mist_dryer.usda`는 Isaac Sim에서 열어 구조를 살펴볼 수 있으며, 위 시작 스크립트를 실행하면 애니메이션과 데이터 발행이 연결됩니다.

## 종료와 로그

```powershell
.\scripts\Status-DryerTwin.ps1
.\scripts\Stop-DryerTwin.ps1
```

시작 오류는 `reports/bridge.log` 또는 `reports/isaac-stderr.log`에서 확인합니다. 설치 후 생성된 `.env`와 Docker 볼륨에는 각 PC의 설정과 실행 이력이 들어 있습니다.
