"""A disk-backed FIFO shared by local producers. The rendering loop never performs HTTP."""
from hashlib import sha256
import json
import logging
import queue
import sqlite3
import sys
import threading
import time
from urllib.error import HTTPError
from urllib.parse import urlsplit
from urllib.request import Request, build_opener

from process import ROOT

sys.path.insert(0, str(ROOT / "bridge"))
from basyx import BaSyx, NoRedirect


class Publisher:
    def __init__(self, root, settings, label):
        self.root = root
        self.settings = settings
        self.inbox = queue.SimpleQueue()
        self.stop = threading.Event()
        self.local_done = threading.Event()
        self.failed = threading.Event()
        self.log = root / "reports" / f"{label}-messages.log"
        self.archive_url = settings.get("ARCHIVE_URL") or f"http://127.0.0.1:{settings['BRIDGE_PORT']}/ingest"
        endpoint = urlsplit(self.archive_url)
        self.spool = root / ".runtime/publisher.sqlite"
        if settings.get("ARCHIVE_URL"):
            suffix = sha256(self.archive_url.encode()).hexdigest()[:16]
            self.spool = root / ".runtime" / f"publisher-{suffix}.sqlite"
        if endpoint.scheme != "https" and endpoint.hostname not in {"127.0.0.1", "localhost", "::1"}:
            raise ValueError("The remote history endpoint must use HTTPS")
        aas_endpoint = urlsplit(settings.get("AAS_URL") or "http://127.0.0.1")
        if aas_endpoint.scheme != "https" and aas_endpoint.hostname not in {"127.0.0.1", "localhost", "::1"}:
            raise ValueError("The remote AAS endpoint must use HTTPS")
        self.opener = build_opener(NoRedirect())
        self.direct = settings.get("AAS_WRITE_MODE", "direct") == "direct"
        self.api = BaSyx(root, settings, json.loads((root / "aas/runtime.json").read_text(encoding="utf-8")))
        self.worker = threading.Thread(target=self.persist, daemon=True)
        self.sender = threading.Thread(target=self.drain, daemon=True)
        self.live_sender = threading.Thread(target=self.drain_live, daemon=True)
        self.worker.start()
        self.sender.start()
        self.live_sender.start()

    def send(self, message):
        if self.failed.is_set():
            raise RuntimeError("Publisher spool persistence failed")
        self.inbox.put(message)

    def sqlite(self):
        db = sqlite3.connect(self.spool, timeout=5)
        db.execute("CREATE TABLE IF NOT EXISTS pending (id INTEGER PRIMARY KEY AUTOINCREMENT, message TEXT NOT NULL)")
        db.execute("""CREATE TABLE IF NOT EXISTS pending_aas (
                    id INTEGER PRIMARY KEY CHECK (id=1), message TEXT NOT NULL, values_json TEXT NOT NULL)""")
        return db

    def persist(self):
        try:
            with self.sqlite() as db, self.log.open("a", encoding="utf-8", buffering=1) as log:
                while True:
                    message = self.inbox.get()
                    if message is None:
                        break
                    if self.direct:
                        message = {**message, "aas_direct": True}
                    payload = json.dumps(message, ensure_ascii=False, allow_nan=False)
                    db.execute("INSERT INTO pending(message) VALUES (?)", (payload,))
                    db.commit()
                    log.write(payload + "\n")
        except Exception as error:
            print(f"Spool persistence failed: {error}", flush=True)
            self.failed.set()
        finally:
            self.local_done.set()

    def drain(self):
        while not self.stop.is_set():
            try:
                with self.sqlite() as db:
                    row = db.execute("SELECT id, message FROM pending ORDER BY id LIMIT 1").fetchone()
                    if row:
                        headers = {"Content-Type": "application/json"}
                        if self.settings.get("ARCHIVE_URL") and self.settings.get("AAS_TOKEN"):
                            headers["Authorization"] = f"Bearer {self.settings['AAS_TOKEN']}"
                        else:
                            headers["X-Dryer-Key"] = self.settings["INGEST_KEY"]
                        request = Request(self.archive_url, data=row[1].encode(), headers=headers)
                        try:
                            with self.opener.open(request, timeout=3) as response:
                                receipt = json.load(response)
                        except HTTPError as error:
                            if error.code in {400, 409, 422}:
                                with (self.root / "reports/publisher-rejected.log").open("a", encoding="utf-8") as log:
                                    log.write(f"{error.code} {error.read().decode()}: {row[1]}\n")
                            else:
                                raise
                        else:
                            if json.loads(row[1]).get("aas_direct") and receipt["active"]:
                                db.execute("""INSERT INTO pending_aas VALUES (1,?,?)
                                              ON CONFLICT(id) DO UPDATE SET message=excluded.message,
                                              values_json=excluded.values_json""", (row[1], json.dumps(receipt["values"])))
                        db.execute("DELETE FROM pending WHERE id=?", (row[0],))
                        db.commit()
                        continue
            except (OSError, sqlite3.Error) as error:
                print(f"Publisher retry: {type(error).__name__}", flush=True)
            self.stop.wait(0.25)

    def drain_live(self):
        while not self.stop.is_set():
            try:
                with self.sqlite() as db:
                    row = db.execute("SELECT message,values_json FROM pending_aas WHERE id=1").fetchone()
                    if row:
                        message = json.loads(row[0])
                        self.api.apply_live(message, json.loads(row[1]))
                        db.execute("DELETE FROM pending_aas WHERE id=1 AND message=?", (row[0],))
                        db.commit()
                        continue
            except (OSError, sqlite3.Error) as error:
                logging.warning("AAS publish retry: %s", error)
            self.stop.wait(.35)

    def close(self):
        self.inbox.put(None)
        self.local_done.wait(10)
        deadline = time.monotonic() + 5
        while time.monotonic() < deadline:
            with self.sqlite() as db:
                if db.execute("SELECT 1 FROM pending UNION ALL SELECT 1 FROM pending_aas LIMIT 1").fetchone() is None:
                    break
            time.sleep(.2)
        self.stop.set()
        self.sender.join(4)
        self.live_sender.join(4)

