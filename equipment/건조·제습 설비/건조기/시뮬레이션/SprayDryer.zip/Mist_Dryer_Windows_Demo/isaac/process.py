"""Deterministic wall-clock-accelerated batch process, independent of rendering and I/O."""
from bisect import bisect_right
from datetime import datetime, timezone
from itertools import accumulate
import json
import math
import os
from pathlib import Path
import time
from uuid import uuid4

ROOT = Path(__file__).resolve().parents[1]


def utc():
    return datetime.now(timezone.utc).isoformat(timespec="milliseconds").replace("+00:00", "Z")


def config():
    path = Path(os.environ.get("MIST_DRYER_ENV", ROOT / ".env"))
    return dict(line.strip().split("=", 1) for line in path.read_text(encoding="utf-8-sig").splitlines()
                if line.strip() and not line.lstrip().startswith("#")) if path.exists() else {}


class Process:
    def __init__(self, catalog, settings, source, send):
        self.catalog = catalog
        self.send = send
        self.source = source
        self.speed = float(settings["SPEED"])
        self.interval = float(settings["SAMPLE_SECONDS"])
        if not (0 < self.speed <= 600 and 0.1 <= self.interval <= 60):
            raise ValueError("SPEED must be in (0,600] and SAMPLE_SECONDS in [0.1,60]")
        self.scenario = settings["SCENARIO"]
        self.kpi_mode = settings["KPI_INPUTS"]
        self.limit = int(settings["DEMO_BATCHES"])
        self.session = str(uuid4())
        self.seq = 0
        self.batch = 1
        self.complete = 0
        self.index = 0
        self.names, durations = zip(*catalog["stages"])
        self.ends = list(accumulate(durations))
        self.total = self.ends[-1]
        self.batch_offset = 0.0
        self.batch_started_at = utc()
        self.start = time.monotonic()
        self.last_sample_wall = -self.interval
        self.prior_alarm = False
        self.prior_fault = False
        self.ready_for_batch = False
        self.done = False
        self.last_sim = 0.0
        self.initialize_run()

    def initialize_run(self):
        self.state = self.state_at(0)
        self.emit("session_start", 0)
        self.emit("batch_start", 0)
        self.emit("phase_enter", 0)

    def state_at(self, simulated):
        elapsed = simulated - self.batch_offset
        recipe = self.catalog["settings"]
        product = self.catalog["product"]
        ambient = 25.0
        inlet_sv = float(recipe["InletAirTemperatureSetpoint"])
        chamber_sv = float(recipe["ChamberTemperatureSetpoint"])
        outlet_sv = 84.0
        preheat_end, dry_end, _ = self.ends
        cool_secs = max(0.0, elapsed - dry_end)
        running = self.index < len(self.names)
        phase = self.names[self.index] if running else "Complete"
        heat_elapsed = min(elapsed, dry_end)
        inlet = ambient + (inlet_sv - ambient) * (1 - math.exp(-heat_elapsed / 145))
        chamber = ambient + (chamber_sv - ambient) * (1 - math.exp(-heat_elapsed / 245))
        outlet = ambient + (outlet_sv - ambient) * (1 - math.exp(-heat_elapsed / 315))
        if cool_secs:
            inlet = ambient + (inlet - ambient) * math.exp(-cool_secs / 175)
            chamber = ambient + (chamber - ambient) * math.exp(-cool_secs / 300)
            outlet = ambient + (outlet - ambient) * math.exp(-cool_secs / 210)
        alarm_injected = self.scenario in {"alarm", "combined"} and preheat_end + 180 <= elapsed < preheat_end + 420
        if alarm_injected:
            inlet += 22.0
        heat = float(phase in ("Preheat", "Dry")) * min(1.0, max(0.0, 0.35 + (inlet_sv - inlet) / 58))
        frequency = {"Preheat": 14.0, "Dry": 45.0, "Cool": 55.0, "Complete": 0.0}[phase]
        frequency_pv = max(0, frequency - 1 + .85 * math.sin(elapsed * 0.017)) if running else 0.0
        hi, lo, out_hi, out_lo = 125.0, 95.0, 97.0, 70.0
        alarm = inlet > hi or outlet > out_hi or (phase == "Dry" and (inlet < lo or outlet < out_lo))
        fault = self.scenario in {"do_fault", "combined"} and preheat_end + 480 <= elapsed < preheat_end + 660
        initial = float(product["InitialMoistureContent"])
        target = float(product["TargetMoistureContent"])
        moisture = initial - (initial - target) * min(1.0, max(0.0, (elapsed - preheat_end) / (dry_end - preheat_end)))
        values = [
            running, heat > .05, heat > .5, heat > .78, heat > .05,
            inlet, inlet_sv, hi, lo, outlet, outlet_sv, out_hi, out_lo, frequency_pv, frequency,
        ]
        raw, engineering = self.encode_signals(values, fault)
        return {"phase": phase, "progress": round(min(100, elapsed / self.total * 100), 3),
                "batch_id": f"{self.session[:8]}-B{self.batch:05d}", "batch_started_at": self.batch_started_at,
                "raw_do": raw, "values": engineering, "heat": heat, "chamber": round(chamber, 3),
                "moisture": round(moisture, 3), "alarm": alarm, "do_fault": fault, "running": running,
                "fan": running, "exhaust_hz": frequency_pv, "damper": frequency / 55,
                "door_angle": 0 if running else -78, "heaters": values[1:4], "scr": values[4]}

    def encode_signals(self, values, fault):
        raw = {}
        engineering = {}
        for signal, value in zip(self.catalog["signals"], values, strict=True):
            name = signal["idShort"]
            if signal["sourceSignalType"] == "DO":
                on, off = signal["sourceSignals"]
                if fault and name == "Heater1RunningState":
                    raw[on], raw[off] = 1, 1
                else:
                    raw[on], raw[off] = int(value), int(not value)
            else:
                engineering[name] = {"value": round(value, 3), "unit": signal["unit"]}
        return raw, engineering

    def emit(self, kind, simulated, state=None):
        state = state or self.state_at(simulated)
        message = {"equipment_id": self.catalog["equipment_id"], "session_id": self.session,
                   "seq": self.seq, "source": self.source, "kind": kind, "observed_at": utc(),
                   "sim_seconds": round(simulated, 6), "speed": self.speed, "expected_seconds": self.interval,
                   "quality": "DoMismatch" if state["do_fault"] else "Synthetic",
                   "kpi_inputs": self.kpi_mode, **state}
        self.send(message)
        self.seq += 1

    def advance(self, simulated):
        if self.ready_for_batch and simulated >= self.batch_offset + self.total + 2 * self.speed:
            self.batch_offset += self.total + 2 * self.speed
            self.batch += 1
            self.index = 0
            self.batch_started_at = utc()
            self.ready_for_batch = False
            self.emit("batch_start", self.batch_offset)
            self.emit("phase_enter", self.batch_offset)
        elapsed = simulated - self.batch_offset
        if not self.ready_for_batch:
            new_index = bisect_right(self.ends, elapsed)
            while self.index < new_index:
                boundary = self.batch_offset + self.ends[self.index]
                self.index += 1
                if self.index == len(self.names):
                    self.emit("batch_complete", boundary)
                    self.complete += 1
                    self.ready_for_batch = True
                    simulated = min(simulated, self.batch_offset + self.total + 2 * self.speed)
                    break
                self.emit("phase_enter", boundary)
        if self.ready_for_batch:
            simulated = min(simulated, self.batch_offset + self.total + 2 * self.speed)
        return simulated

    def should_finish(self):
        return self.limit and self.complete >= self.limit

    def tick(self):
        if self.done:
            return self.state
        wall = time.monotonic() - self.start
        simulated = self.advance(wall * self.speed)
        self.last_sim = simulated
        self.state = self.state_at(simulated)
        if self.state["alarm"] != self.prior_alarm:
            self.prior_alarm = self.state["alarm"]
            self.emit("alarm_on" if self.prior_alarm else "alarm_clear", simulated, self.state)
        if self.state["do_fault"] != self.prior_fault:
            self.prior_fault = self.state["do_fault"]
            self.emit("do_invalid" if self.prior_fault else "do_recovered", simulated, self.state)
        if wall - self.last_sample_wall >= self.interval:
            self.last_sample_wall = wall
            self.emit("sample", simulated, self.state)
        if self.should_finish():
            self.finish()
        return self.state

    def finish(self):
        if not self.done:
            stopped = dict(self.state)
            for signal in self.catalog["signals"]:
                if signal["sourceSignalType"] == "DO":
                    on, off = signal["sourceSignals"]
                    stopped["raw_do"] = {**stopped["raw_do"], on: 0, off: 1}
            stopped.update(running=False, heaters=[False]*3, scr=False, fan=False, damper=0,
                           exhaust_hz=0, do_fault=False)
            for name in ("OutletInverterActualValue", "OutletInverterSetpoint"):
                stopped["values"] = {**stopped["values"], name: {"value": 0, "unit": "Hz"}}
            if "feed_lph" in stopped:
                stopped["feed_lph"] = 0.0
            self.state = stopped
            self.emit("session_end", self.last_sim, stopped)
            self.done = True

