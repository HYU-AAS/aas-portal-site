"""Open the animated pilot spray dryer from the installed Isaac Sim launcher."""
import json
import os
import time

from continuous_spray import ContinuousSprayProcess
from process import ROOT, config
from publisher import Publisher
from isaacsim import SimulationApp

settings = config()
if "MIST_DRYER_BATCHES" in os.environ:
    settings["DEMO_BATCHES"] = os.environ["MIST_DRYER_BATCHES"]
app = SimulationApp({"headless":False, "width":1440, "height":900, "sync_loads":True,
                     "renderer":"RaytracedLighting", "disable_viewport_updates":False})
import omni.ui as ui
import omni.usd
import omni.kit.viewport.utility as viewport

from build_scene import CAMERA_VIEWS, DEVICE, OUTPUT, PHASE_VIEWS, build
from spray_motion import SprayMotion


def load_stage():
    if not OUTPUT.exists():
        build()
    context = omni.usd.get_context()
    context.open_stage(str(OUTPUT))
    for _ in range(120):
        app.update()
        stage = context.get_stage()
        if stage and stage.GetPrimAtPath(DEVICE+"/Tower/Nozzle/Tip"):
            return stage
    raise RuntimeError(f"Spray dryer USD did not load: {OUTPUT}")


def simulate():
    stage = load_stage()
    vp = viewport.get_active_viewport()
    motion = SprayMotion(stage)
    phase = "Preheat"
    follow_phase = True
    panel = ui.Window("Mist Dryer | Spray drying", width=329, height=238)
    panel.position_x = 1057
    panel.position_y = 472

    def show_view(view_name):
        view = CAMERA_VIEWS[view_name]
        motion.set_section(view["section"])
        vp.set_active_camera("/World/" + view["prim"])

    def select_view(view_name=None):
        nonlocal follow_phase
        follow_phase = view_name is None
        show_view(PHASE_VIEWS[phase] if follow_phase else view_name)

    select_view()

    with panel.frame:
        with ui.VStack(spacing=5):
            ui.Label("Two-fluid nozzle  /  Pilot spray dryer", height=23)
            phase_label = ui.Label("",style={"font_size":22},height=30)
            batch_label = ui.Label("",height=20)
            flow_label = ui.Label("",height=21)
            clock_label = ui.Label("",height=21)
            ui.Label("Amber: preheat   Cyan: spray   Blue: cooling",height=20)
            with ui.HStack(height=27):
                ui.Button("Auto", clicked_fn=select_view)
                ui.Button("Overview",clicked_fn=lambda:select_view("section"))
                ui.Button("Nozzle",clicked_fn=lambda:select_view("nozzle"))
                ui.Button("Exterior",clicked_fn=lambda:select_view("exterior"))

    for _ in range(10):
        app.update()
    catalog = json.loads((ROOT/"aas/runtime.json").read_text(encoding="utf-8"))
    publisher = Publisher(ROOT,settings,"isaac")
    proc = None
    try:
        proc = ContinuousSprayProcess(catalog,settings,"isaac_sim",publisher.send)
        print(f"Isaac spray dryer ready; session={proc.session} stage={OUTPUT}",flush=True)
        stop_path = ROOT/".runtime/stop-isaac"
        last = time.monotonic()
        previous = None
        labels = {"Preheat":"Preheat","Dry":"Atomize & dry","Cool":"Cool & purge","Complete":"Run complete"}
        while app.is_running() and not stop_path.exists():
            state = proc.tick()
            now = time.monotonic()
            if phase != state["phase"]:
                phase = state["phase"]
                if follow_phase:
                    show_view(PHASE_VIEWS[phase])
            flow = motion.update(state, not proc.done, min(now-last, .1))
            last = now
            phase_label.text = f"{labels[state['phase']]}   {state['progress']:.0f}%"
            batch_label.text = f"{state['batch_id']}  |  {proc.complete} complete"
            flow_label.text = f"Nozzle {'ON' if flow['Mist'] else 'OFF'}   |   Recovery {'ON' if flow['Powder'] else 'OFF'}"
            clock_label.text = f"Feed {state['feed_lph']:.2f} L/h  |  Lot {proc.lot_seconds/60:g} min ×{proc.speed:g}"
            key = state["phase"], tuple(flow.values())
            if previous != key:
                print(f"Spray flow session={proc.session} batch={state['batch_id']} phase={state['phase']} "
                      f"camera={vp.camera_path} prim_visibility={flow}",flush=True)
                previous = key
            app.update()
    finally:
        if proc is not None:
            proc.finish()
        publisher.close()


try:
    simulate()
finally:
    app.close()

