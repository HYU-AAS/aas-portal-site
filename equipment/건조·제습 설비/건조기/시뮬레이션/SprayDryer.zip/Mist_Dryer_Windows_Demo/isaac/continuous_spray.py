"""Continuous spray drying with lot boundaries independent of the equipment state."""
from bisect import bisect_right
from functools import lru_cache
from math import exp, sin
from random import Random

from process import Process, utc

AMBIENT = 25.0
FEED_BASE_LPH = 4.5
FEED_VARIATION_LPH = 0.7
FEED_RAMP_SECONDS = 90.0
FEED_CHANGE_SECONDS = (180, 600)
OUTLET_RESPONSE_SECONDS = 105.0
NO_FEED_OUTLET_RISE = 11.0
FEED_COOLING_DEGREES_PER_LPH = NO_FEED_OUTLET_RISE / FEED_BASE_LPH
ALARM_FEED_STOP_SECONDS = 180.0
ALARM_FEED_RESUME_SECONDS = 420.0
INLET_DRIFT_INTERVAL_SECONDS = 600.0
INLET_DRIFT_LIMIT_C = 0.15


def approach(start, target, elapsed, time_constant):
    return target + (start - target) * exp(-elapsed / time_constant)


@lru_cache(maxsize=8)
def inlet_drift_target(index):
    if index == 0:
        return 0.0
    return Random(index).uniform(-INLET_DRIFT_LIMIT_C, INLET_DRIFT_LIMIT_C)


def inlet_drift(elapsed):
    """Interpolate bounded offsets in simulated time, independent of sample order."""
    interval, position = divmod(elapsed, INLET_DRIFT_INTERVAL_SECONDS)
    index = int(interval)
    fraction = position / INLET_DRIFT_INTERVAL_SECONDS
    blend = fraction**2 * (3 - 2 * fraction)
    start = inlet_drift_target(index)
    return start + (inlet_drift_target(index + 1) - start) * blend


def ramp_response(lagged, feed, slope, elapsed):
    """Solve the first-order thermal response to a linear supply ramp."""
    ramp_offset = slope * OUTLET_RESPONSE_SECONDS
    return approach(lagged, feed - ramp_offset, elapsed, OUTLET_RESPONSE_SECONDS) + slope * elapsed


class ContinuousSprayProcess(Process):
    def initialize_run(self):
        self.preheat_seconds, self.lot_seconds, self.cool_seconds = (
            self.ends[0], self.ends[1] - self.ends[0], self.ends[2] - self.ends[1]
        )
        self.batch_offset = self.preheat_seconds
        self.feed_random = Random(2026)
        self.feed_points = [(0.0, 0.0, 0.0),
                            (FEED_RAMP_SECONDS, FEED_BASE_LPH,
                             ramp_response(0.0, 0.0, FEED_BASE_LPH / FEED_RAMP_SECONDS, FEED_RAMP_SECONDS))]
        self.cool_started = None
        self.phase = "Preheat"
        self.state = self.state_at(0)
        self.emit("session_start", 0, self.state)
        self.emit("phase_enter", 0, self.state)

    def scheduled_feed(self, elapsed):
        while elapsed >= self.feed_points[-1][0]:
            start, feed, lagged = self.feed_points[-1]
            duration = self.feed_random.randint(*FEED_CHANGE_SECONDS)
            next_feed = FEED_BASE_LPH + self.feed_random.uniform(-FEED_VARIATION_LPH, FEED_VARIATION_LPH)
            lagged = ramp_response(lagged, feed, (next_feed - feed) / duration, duration)
            self.feed_points.append((start + duration, next_feed, lagged))
        index = bisect_right(self.feed_points, (elapsed, float("inf"))) - 1
        start, feed, lagged = self.feed_points[index]
        end, next_feed, _ = self.feed_points[index + 1]
        slope = (next_feed - feed) / (end - start)
        offset = elapsed - start
        return feed + slope * offset, ramp_response(lagged, feed, slope, offset)

    def feed_at(self, elapsed):
        feed, lagged = self.scheduled_feed(elapsed)
        start, end = ALARM_FEED_STOP_SECONDS, ALARM_FEED_RESUME_SECONDS
        if self.scenario not in {"alarm", "combined"} or elapsed < start:
            return feed, lagged
        _, at_stop = self.scheduled_feed(start)
        if elapsed < end:
            return 0.0, approach(at_stop, 0.0, elapsed - start, OUTLET_RESPONSE_SECONDS)
        _, normal_at_resume = self.scheduled_feed(end)
        at_resume = approach(at_stop, 0.0, end - start, OUTLET_RESPONSE_SECONDS)
        return feed, lagged + approach(at_resume - normal_at_resume, 0.0, elapsed - end, OUTLET_RESPONSE_SECONDS)

    def state_at(self, simulated):
        recipe = self.catalog["settings"]
        inlet_sv = float(recipe["InletAirTemperatureSetpoint"])
        chamber_sv = float(recipe["ChamberTemperatureSetpoint"])
        outlet_sv = 84.0
        idle_outlet = outlet_sv + NO_FEED_OUTLET_RISE
        warm = min(simulated, self.preheat_seconds)
        inlet = approach(AMBIENT, inlet_sv, warm, 125)
        chamber = approach(AMBIENT, chamber_sv, warm, 205)
        outlet = approach(AMBIENT, idle_outlet, warm, 135)
        feed = 0.0
        moisture = float(self.catalog["product"]["TargetMoistureContent"])
        production = max(0.0, simulated - self.preheat_seconds)
        run_time = production
        if self.cool_started is not None:
            run_time = self.cool_started - self.preheat_seconds
        if self.phase != "Preheat":
            feed, lagged_feed = self.feed_at(run_time)
            inlet = approach(inlet, inlet_sv, run_time, 65) + inlet_drift(run_time)
            chamber = approach(chamber, chamber_sv, run_time, 115)
            outlet = (approach(outlet, idle_outlet, run_time, OUTLET_RESPONSE_SECONDS)
                      - FEED_COOLING_DEGREES_PER_LPH * lagged_feed)
        if self.cool_started is not None:
            cooling = max(0.0, simulated - self.cool_started)
            inlet = approach(inlet, AMBIENT, cooling, 175)
            outlet = approach(outlet, AMBIENT, cooling, 210)
            chamber = approach(chamber, AMBIENT, cooling, 300)
            feed = 0.0

        fault = self.phase == "Dry" and self.scenario in {"do_fault", "combined"} and 480 <= production < 660
        injected = (self.phase == "Dry" and self.scenario in {"alarm", "combined"}
                    and ALARM_FEED_STOP_SECONDS <= production < ALARM_FEED_RESUME_SECONDS)
        if injected:
            inlet += 22.0
        heat = min(1.0, max(0.0, .35 + (inlet_sv - inlet) / 58)) if self.phase in {"Preheat", "Dry"} else 0.0
        running = self.phase != "Complete"
        frequency = {"Preheat": 14.0, "Dry": 45.0, "Cool": 55.0, "Complete": 0.0}[self.phase]
        actual_hz = frequency - 1 + .65 * sin(simulated / 43) if running else 0.0
        limits = (125.0, 95.0, 97.0, 70.0)
        alarm = inlet > limits[0] or outlet > limits[2] or (
            self.phase == "Dry" and (inlet < limits[1] or outlet < limits[3])
        )
        if alarm:
            feed = 0.0
        progress = max(0.0, min(100.0, 100 * (simulated - self.batch_offset) / self.lot_seconds))
        values = [running, heat > .05, heat > .5, heat > .78, heat > .05,
                  inlet, inlet_sv, limits[0], limits[1], outlet, outlet_sv, limits[2], limits[3], actual_hz, frequency]
        raw, engineering = self.encode_signals(values, fault)
        return {"phase": self.phase, "progress": round(progress, 3),
                "batch_id": f"{self.session[:8]}-B{self.batch:05d}", "batch_started_at": self.batch_started_at,
                "raw_do": raw, "values": engineering, "heat": heat, "chamber": round(chamber, 3),
                "moisture": moisture, "alarm": alarm, "do_fault": fault, "running": running, "fan": running,
                "exhaust_hz": actual_hz, "heaters": values[1:4], "scr": values[4], "damper": frequency / 55,
                "door_angle": 0.0, "feed_lph": round(feed, 4), "process_mode": "continuous_spray",
                "target_batch_seconds": self.lot_seconds,
                "purging_powder": self.phase == "Cool" and simulated - self.cool_started < .28 * self.cool_seconds}

    def advance(self, simulated):
        if self.phase == "Preheat" and simulated >= self.preheat_seconds:
            self.phase = "Dry"
            self.batch_started_at = utc()
            self.emit("batch_start", self.preheat_seconds)
            self.emit("phase_enter", self.preheat_seconds)
        while self.phase == "Dry" and simulated >= self.batch_offset + self.lot_seconds:
            boundary = self.batch_offset + self.lot_seconds
            self.emit("batch_complete", boundary)
            self.complete += 1
            if self.limit and self.complete >= self.limit:
                self.phase = "Cool"
                self.cool_started = boundary
                self.emit("phase_enter", boundary)
                break
            self.batch_offset = boundary
            self.batch += 1
            self.batch_started_at = utc()
            self.emit("batch_start", boundary)
        if self.phase == "Cool" and simulated >= self.cool_started + self.cool_seconds:
            end = self.cool_started + self.cool_seconds
            self.phase = "Complete"
            self.emit("phase_enter", end)
            return end
        return simulated

    def should_finish(self):
        return self.phase == "Complete"

