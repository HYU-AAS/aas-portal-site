import json
import signal
import time
import argparse

from process import ROOT, Process, config
from continuous_spray import ContinuousSprayProcess
from publisher import Publisher

settings = config()
parser = argparse.ArgumentParser()
parser.add_argument("--legacy-batches", action="store_true")
args = parser.parse_args()
catalog = json.loads((ROOT / "aas/runtime.json").read_text(encoding="utf-8"))
publisher = Publisher(ROOT, settings, "mock")
running = True


def stop(*args):
    global running
    running = False


signal.signal(signal.SIGINT, stop)
signal.signal(signal.SIGTERM, stop)
process_type = Process if args.legacy_batches else ContinuousSprayProcess
process = process_type(catalog, settings, "mock", publisher.send)
try:
    while running and not process.done:
        process.tick()
        time.sleep(0.025)
finally:
    process.finish()
    publisher.close()

