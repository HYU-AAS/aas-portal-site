"""Display the physics-inspired flow paths of the spray dryer for the existing demo clock."""
from math import cos, pi, sin, sqrt
from random import Random

from pxr import Gf, UsdGeom, UsdShade, Vt

from build_scene import CLEAN_AIR_PATH, DEVICE, EXHAUST_PATH, FLOW_POINTS, INDICATORS, NOZZLE_TIP

MIST_SPREAD = .22
POWDER_PATHS = (
    ((.0,.0,1.09),(.0,.0,.50),(.0,.0,.26)),
    ((1.23,-.13,1.92),(1.09,-.13,1.56),(1.23,-.045,.68),(1.23,-.035,.33)),
)
AIR_STYLES = {
    "Preheat": {"material": "PreheatAir", "rgb": [1.0, .45, .12], "speed": .34},
    "Dry": {"material": "DryingAir", "rgb": [.08, .76, .92], "speed": .57},
    "Cool": {"material": "CoolingAir", "rgb": [.38, .65, 1.0], "speed": .88},
}
STREAM_SPEEDS = {"Mist": .81, "Exhaust": .68, "Powder": .86}


def stream_speed(name, phase, exhaust_hz):
    if name == "DryingAir":
        return AIR_STYLES.get(phase, AIR_STYLES["Dry"])["speed"]
    if name == "Exhaust":
        return STREAM_SPEEDS[name] * exhaust_hz / 45
    return STREAM_SPEEDS[name]


def polyline(points, ratio):
    scaled = ratio * (len(points)-1)
    index = min(int(scaled), len(points)-2)
    a, b = points[index:index+2]
    return tuple(x+(y-x)*(scaled-index) for x,y in zip(a,b))


def spray_point(kind, index, ratio, angle, spread):
    if kind in {"Mist", "DryingAir"}:
        distance = .012 + ratio * (1.37 if kind == "DryingAir" else 1.02)
        radius = (.085+.153*ratio) if kind == "DryingAir" else MIST_SPREAD*ratio*sqrt(spread)
        spin = angle + .72 * ratio
        return (radius*cos(spin),radius*sin(spin),NOZZLE_TIP-distance)
    if kind == "Exhaust":
        # Markers float beside the opaque duct so the exhaust route remains readable.
        path = EXHAUST_PATH if index % 2 == 0 else CLEAN_AIR_PATH
        x,y,z = polyline(path, ratio)
        return x, y-.078, z+.035
    x,y,z = polyline(POWDER_PATHS[index%2],ratio)
    radius = (1-ratio)*.033
    return x+radius*cos(angle), y+radius*sin(angle), z


def flow_state(state, running):
    phase = state["phase"] if running else "Complete"
    alarm = running and state["alarm"]
    mist = phase == "Dry" and not alarm and state.get("feed_lph", 1.0) > 0
    air = running and state["fan"] and phase != "Complete"
    # During cool-down the nozzle is off and residual powder recovery winds down.
    purging = phase == "Cool" and state.get("purging_powder", state["progress"] < 94.5)
    return {"Mist":mist, "DryingAir":air, "Exhaust":air and state["exhaust_hz"]>0,
            "Powder":mist or purging}


class SprayMotion:
    def __init__(self, stage):
        self.stage = stage
        self.section = True
        self.visibility = {}
        self.previous_lights = None
        self.air_material = None
        self.positions = dict.fromkeys(FLOW_POINTS, 0.0)
        self.rotor = self.prim("Recovery/ExhaustFan").GetAttribute("xformOp:rotateY")
        self.streams = {}
        rng = Random(456)
        for name,count in FLOW_POINTS.items():
            prim = self.prim("Flows/"+name)
            samples = [(rng.random(),rng.random()*2*pi,rng.random()) for _ in range(count)]
            self.streams[name] = (UsdGeom.Points(prim),samples)
        self.bindings = [UsdShade.MaterialBindingAPI(self.prim(name)) for name in INDICATORS]
        self.materials = {name:UsdShade.Material(stage.GetPrimAtPath(f"/World/Materials/{name}"))
                          for name in ("LampIdle","HeaterOn","SignalGreen","AlarmRed")}
        air_prim = self.prim("Flows/DryingAir")
        self.air_binding = UsdShade.MaterialBindingAPI(air_prim)
        self.air_display = UsdGeom.Gprim(air_prim).GetDisplayColorAttr()
        self.air_materials = {
            phase: UsdShade.Material(stage.GetPrimAtPath("/World/Materials/" + style["material"]))
            for phase, style in AIR_STYLES.items()
        }
        self.set_section(True)

    def prim(self, path):
        prim = self.stage.GetPrimAtPath(DEVICE+"/"+path)
        if not prim:
            raise RuntimeError(f"Spray dryer prim missing: {path}")
        return prim

    @staticmethod
    def show(prim, enabled):
        if enabled:
            UsdGeom.Imageable(prim).MakeVisible()
        else:
            UsdGeom.Imageable(prim).MakeInvisible()

    def set_section(self, section):
        self.section = section
        for name in ("Section","SectionBands","SectionEdges"):
            self.show(self.prim("Tower/"+name),section)
        for name in ("Shell","ExteriorBands","SightGlass"):
            self.show(self.prim("Tower/"+name),not section)

    def update(self, state, running, dt):
        enabled = flow_state(state,running)
        if enabled["Exhaust"]:
            self.rotor.Set((self.rotor.Get() + dt * state["exhaust_hz"] * 13) % 360)
        phase = state["phase"]
        if enabled["DryingAir"] and self.air_material != phase:
            self.air_binding.Bind(self.air_materials[phase])
            self.air_display.Set(Vt.Vec3fArray([Gf.Vec3f(*AIR_STYLES[phase]["rgb"])]))
            self.air_material = phase
        for name,(points,samples) in self.streams.items():
            active = enabled[name]
            if self.visibility.get(name) != active:
                self.show(points.GetPrim(),active)
                self.visibility[name] = active
            if not active:
                continue
            velocity = stream_speed(name, phase, state["exhaust_hz"])
            self.positions[name] = (self.positions[name] + dt * velocity) % 1
            ratio = [(self.positions[name] + sample[0]) % 1 for sample in samples]
            positions = [Gf.Vec3f(*spray_point(name,i,t,angle,spread))
                         for i,(t,(_,angle,spread)) in enumerate(zip(ratio,samples,strict=True))]
            points.GetPointsAttr().Set(Vt.Vec3fArray(positions))
            if name == "Mist":
                points.GetWidthsAttr().Set(Vt.FloatArray([.018-.010*t for t in ratio]))
        lamps = [("HeaterOn" if on and running else "LampIdle") for on in state["heaters"]]
        lamps.extend(("SignalGreen" if running and state["scr"] else "LampIdle",
                      "AlarmRed" if running and state["alarm"] else "LampIdle",
                      "SignalGreen" if enabled["Mist"] else "LampIdle"))
        if lamps != self.previous_lights:
            for binding,name in zip(self.bindings,lamps,strict=True):
                binding.Bind(self.materials[name])
            self.previous_lights = lamps
        return enabled

