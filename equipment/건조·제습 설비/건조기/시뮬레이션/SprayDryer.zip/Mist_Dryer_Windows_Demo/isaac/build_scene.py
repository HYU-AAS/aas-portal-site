"""Build the pilot, open-cycle spray dryer demonstration stage."""
import argparse
from math import cos, pi, radians, sin, tan
from pathlib import Path

from pxr import Gf, Sdf, Usd, UsdGeom, UsdLux, UsdShade, Vt

OUTPUT = Path(__file__).resolve().parent / "assets/mist_dryer.usda"
DEVICE = "/World/MistDryer"
NOZZLE_TIP = 2.24
HEATER_BANDS = ("HotAir/Heater1", "HotAir/Heater2", "HotAir/Heater3")
INDICATORS = (*HEATER_BANDS, "Controls/SCR", "Controls/Alarm", "Feed/PumpLamp")
FLOW_POINTS = {"Mist": 172, "DryingAir": 62, "Exhaust": 34, "Powder": 36}
# Chamber exit to cyclone tangential inlet, then through the final filter and fan.
EXHAUST_PATH = ((.32, 0, 1.29), (.64, 0, 1.29), (.72, .20, 1.87), (1.12, .20, 1.87))
CLEAN_AIR_PATH = ((1.23, .07, 2.12), (1.23, .07, 2.29), (1.72, .07, 2.29),
                  (1.72, .07, 1.78), (2.19, .07, 1.78), (2.19, .07, 2.86))
CAMERA_VIEWS = {
    "section": dict(prim="Overview", eye=(2.40, -6.7, 3.2), target=(.35, 0, 1.4), fov=37, section=True),
    "heat": dict(prim="HeaterView", eye=(-3.5, -4.0, 2.9), target=(-.59, 0, 1.93), fov=32, section=True),
    "nozzle": dict(prim="Interior", eye=(.42, -3.45, 2.58), target=(0, 0, 1.79), fov=31, section=True),
    "exhaust": dict(prim="ExhaustView", eye=(3.75, -4.55, 2.93), target=(1.4, 0, 1.55), fov=33, section=True),
    "exterior": dict(prim="ExteriorView", eye=(3.5, -6.2, 2.9), target=(.35, 0, 1.4), fov=37, section=False),
}
PHASE_VIEWS = {"Preheat": "heat", "Dry": "nozzle", "Cool": "exhaust", "Complete": "exterior"}


def define_cameras(stage):
    for view in CAMERA_VIEWS.values():
        camera = UsdGeom.Camera.Define(stage, "/World/" + view["prim"])
        matrix = Gf.Matrix4d().SetLookAt(Gf.Vec3d(*view["eye"]), Gf.Vec3d(*view["target"]), Gf.Vec3d(0, 0, 1))
        UsdGeom.Xformable(camera).MakeMatrixXform().Set(matrix.GetInverse())
        focal = camera.GetVerticalApertureAttr().Get() / (2 * tan(radians(view["fov"]) / 2))
        camera.CreateFocalLengthAttr(focal)
        camera.CreateClippingRangeAttr(Gf.Vec2f(.02, 80))


def build(output=OUTPUT):
    output.parent.mkdir(parents=True, exist_ok=True)
    stage = Usd.Stage.CreateInMemory()
    UsdGeom.SetStageMetersPerUnit(stage, 1)
    UsdGeom.SetStageUpAxis(stage, UsdGeom.Tokens.z)
    world = UsdGeom.Xform.Define(stage, "/World")
    stage.SetDefaultPrim(world.GetPrim())
    stage.GetRootLayer().documentation = "DRYER-SIM-01 | co-current two-fluid nozzle pilot spray dryer | conceptual visualization"
    UsdGeom.Scope.Define(stage, "/World/Materials")

    def material(name, rgb, metallic=0.0, roughness=.4, emission=0.0, opacity=1.0):
        path = f"/World/Materials/{name}"
        mat = UsdShade.Material.Define(stage, path)
        shader = UsdShade.Shader.Define(stage, path + "/Surface")
        shader.CreateIdAttr("UsdPreviewSurface")
        shader.CreateInput("diffuseColor", Sdf.ValueTypeNames.Color3f).Set(Gf.Vec3f(*rgb))
        shader.CreateInput("metallic", Sdf.ValueTypeNames.Float).Set(metallic)
        shader.CreateInput("roughness", Sdf.ValueTypeNames.Float).Set(roughness)
        if opacity < 1:
            shader.CreateInput("opacity", Sdf.ValueTypeNames.Float).Set(opacity)
        if emission:
            shader.CreateInput("emissiveColor", Sdf.ValueTypeNames.Color3f).Set(Gf.Vec3f(*(v*emission for v in rgb)))
        mat.CreateSurfaceOutput().ConnectToSource(shader.ConnectableAPI(), "surface")
        return mat

    steel = material("Stainless", (.58,.62,.64), .72, .34)
    satin = material("Satin", (.37,.41,.43), .62, .47)
    polished = material("Trim", (.77,.84,.88), .76, .20)
    graphite = material("Graphite", (.035,.055,.077), .21)
    frame = material("Skid", (.08,.14,.19), .39)
    blue = material("FeedBlue", (.025,.31,.54), .32)
    gasket = material("Gasket", (.055,.059,.056), .02, .72)
    coated = material("PanelCoating", (.58,.61,.59), .12, .52)
    glass = material("SightGlass", (.25,.53,.57), .10, .16, opacity=.44)
    brass = material("Brass", (.53,.32,.12), .62, .34)
    teal = material("DryingAir", (.08,.76,.92), .13, .3, .75)
    material("PreheatAir", (1.0, .45, .12), 0, .35, 1.0)
    material("CoolingAir", (.38, .65, 1.0), 0, .35, .85)
    amber = material("Powder", (1.0,.66,.22), .0, .42, .95)
    material("MistLight", (.44,.81,1.0), 0, .31, 1.2)
    material("LampIdle", (.21,.12,.063), .2)
    material("HeaterOn", (1.0,.23,.033), 0, .28, 2.1)
    material("SignalGreen", (.06,.80,.43), 0, .30, 1.1)
    material("AlarmRed", (.97,.039,.027), 0, .35, 1.5)
    lamp_idle = UsdShade.Material(stage.GetPrimAtPath("/World/Materials/LampIdle"))
    floor = material("Floor", (.17,.23,.29), .2, .51)

    def bind(shape, mat):
        UsdShade.MaterialBindingAPI.Apply(shape.GetPrim()).Bind(mat)

    def xf(path, pos=(0,0,0), axis=None):
        shape = UsdGeom.Xform.Define(stage, path)
        shape.AddTranslateOp().Set(Gf.Vec3d(*pos))
        if axis:
            getattr(shape, "AddRotate" + axis + "Op")().Set(0.0)
        return shape

    def box(path, pos, size, mat, tilt=0):
        shape = UsdGeom.Cube.Define(stage, path)
        shape.CreateSizeAttr(1)
        shape.AddTranslateOp().Set(Gf.Vec3d(*pos))
        if tilt:
            shape.AddRotateYOp().Set(tilt)
        shape.AddScaleOp().Set(Gf.Vec3f(*size))
        bind(shape,mat)
        return shape

    def tube(path, first, last, radius, mat):
        p, q = Gf.Vec3d(*first), Gf.Vec3d(*last)
        line = q-p
        shape = UsdGeom.Cylinder.Define(stage, path)
        shape.CreateRadiusAttr(radius)
        shape.CreateHeightAttr(line.GetLength())
        shape.AddTranslateOp().Set((p+q)*.5)
        rotation = Gf.Rotation(Gf.Vec3d(0,0,1), line.GetNormalized())
        shape.AddOrientOp().Set(Gf.Quatf(rotation.GetQuat()))
        bind(shape,mat)
        return shape

    def pipe(path, points, radius, mat):
        for i, (start, end) in enumerate(zip(points,points[1:])):
            tube(f"{path}/Run{i}",start,end,radius,mat)
        for i, point in enumerate(points[1:-1], 1):
            corner = UsdGeom.Sphere.Define(stage,f"{path}/Bend{i}")
            corner.CreateRadiusAttr(radius)
            corner.AddTranslateOp().Set(Gf.Vec3d(*point))
            bind(corner,mat)

    def fitting(path, center, axis, radius, bore, length, mat, bolts=0):
        origin = Gf.Vec3d(*center)
        normal = Gf.Vec3d(*axis).GetNormalized()
        right = Gf.Cross(normal, Gf.Vec3d(0, 1, 0) if abs(normal[1]) < .9 else Gf.Vec3d(1, 0, 0)).GetNormalized()
        up = Gf.Cross(normal, right)
        steps = 32
        coords = [origin + normal*depth + radial*(right*cos(2*pi*i/steps) + up*sin(2*pi*i/steps))
                  for depth, radial in [(-length/2, radius), (length/2, radius), (length/2, bore), (-length/2, bore)]
                  for i in range(steps)]
        faces = []
        for row in range(4):
            current, following = row * steps, ((row + 1) % 4) * steps
            for i in range(steps):
                j = (i + 1) % steps
                faces.extend((current + i, current + j, following + j, following + i))
        mesh = UsdGeom.Mesh.Define(stage, path + "/Ring")
        mesh.CreatePointsAttr(Vt.Vec3fArray([Gf.Vec3f(*v) for v in coords]))
        mesh.CreateFaceVertexCountsAttr(Vt.IntArray([4]*(len(faces)//4)))
        mesh.CreateFaceVertexIndicesAttr(Vt.IntArray(faces))
        mesh.CreateDoubleSidedAttr(True)
        mesh.CreateSubdivisionSchemeAttr("none")
        bind(mesh, mat)
        for i in range(bolts):
            angle = 2*pi*i/bolts + pi/bolts
            radial = (right*cos(angle) + up*sin(angle)) * (radius*.78)
            tube(f"{path}/Bolt{i}", origin + radial - normal*(length/2+.004),
                 origin + radial + normal*(length/2+.004), radius*.075, polished)

    def vessel(path, x, y, profile, mat, cut=False, thickness=0):
        # The cutaway exposes the wall at the two edges of the opening.
        steps = 72
        a0, a1 = ((-pi*.2, pi*1.2) if cut else (0, pi*2))
        angles = [a0+(a1-a0)*i/steps for i in range(steps+1)]
        if thickness:
            outer = profile
            profile = outer + [(z, radius-thickness) for z,radius in reversed(outer)] + [outer[0]]
        points = [Gf.Vec3f(x+r*cos(a), y+r*sin(a), z) for z,r in profile for a in angles]
        faces = []
        for row in range(len(profile)-1):
            start = row*(steps+1)
            for i in range(steps):
                k = start+i
                faces.extend((k,k+1,k+steps+2,k+steps+1))
        if cut and thickness:
            stride = steps + 1
            for i in (0, steps):
                for row in range(len(outer)-1):
                    front = row * stride + i
                    back = (2 * len(outer) - 1 - row) * stride + i
                    faces.extend((front, front + stride, back - stride, back))
        mesh = UsdGeom.Mesh.Define(stage,path)
        mesh.CreatePointsAttr(Vt.Vec3fArray(points))
        mesh.CreateFaceVertexCountsAttr(Vt.IntArray([4]*(len(faces)//4)))
        mesh.CreateFaceVertexIndicesAttr(Vt.IntArray(faces))
        mesh.CreateDoubleSidedAttr(True)
        mesh.CreateSubdivisionSchemeAttr("none")
        bind(mesh,mat)
        return UsdGeom.Imageable(mesh.GetPrim())

    b = DEVICE
    xf(b)
    box("/World/Floor",(0,0,-.095),(22,18,.16),floor)
    box(b+"/Support/Deck",(.32,.07,.065),(4.37,1.24,.13),frame)
    for i,x in enumerate((-1.62,-.96,.20,1.52,2.22)):
        for j,y in enumerate((-.43,.57)):
            tube(f"{b}/Support/Leveller{i}_{j}",(x,y,.013),(x,y,.065),.036,satin)
            tube(f"{b}/Support/LevellerPad{i}_{j}",(x,y,.001),(x,y,.014),.053,gasket)
    for i,(x,y) in enumerate([(-.38,-.33),(-.38,.34),(.38,-.33),(.38,.34)]):
        tube(b+f"/Support/TowerLeg{i}",(x,y,.135),(x,y,1.40),.031,satin)
        box(b+f"/Support/FloorPlate{i}",(x,y,.14),(.14,.14,.022),steel)
    for z in (.36,1.20):
        for y in (-.33,.34):
            box(b+f"/Support/Brace_{int(z*100)}_{int((y+.4)*100)}",(0,y,z),(.79,.032,.04),frame)

    # A 0.70 m ID x 1.04 m straight section and 0.62 m cone approximate 0.494 m³.
    profile = [(0.45,.054),(0.47,.055),(1.09,.350),(2.13,.350),(2.158,.348),
               (2.28,.283),(2.35,.162),(2.37,.126)]
    vessel(b+"/Tower/Shell",0,0,profile,steel,thickness=.012).MakeInvisible()
    vessel(b+"/Tower/Section",0,0,profile,steel,cut=True,thickness=.012)
    for name in ("SectionBands","ExteriorBands","SectionEdges","SightGlass"):
        xf(b+"/Tower/"+name)
    for name,z,radius in [("ConeFlange",1.09,.363),("TopFlange",2.145,.362),
                          ("RoofCollar",2.37,.142),("OutletFlange",.46,.092)]:
        band=[(z-.017,radius),(z+.017,radius)]
        vessel(b+f"/Tower/SectionBands/{name}",0,0,band,polished,True)
        vessel(b+f"/Tower/ExteriorBands/{name}",0,0,band,polished)
        for i in range(16):
            angle = 2*pi*i/16
            x,y = (radius-.009)*cos(angle), (radius-.009)*sin(angle)
            for group in ("ExteriorBands", "SectionBands"):
                if group == "SectionBands" and not (-pi*.2 <= ((angle+pi*.2) % (2*pi))-pi*.2 <= pi*1.2):
                    continue
                tube(f"{b}/Tower/{group}/{name}Fasteners/Bolt{i}",(x,y,z-.024),(x,y,z+.024),.006,satin)
    UsdGeom.Imageable(stage.GetPrimAtPath(b+"/Tower/ExteriorBands")).MakeInvisible()
    for index,a in enumerate((-pi*.2, pi*1.2)):
        for i, ((z1,r1),(z2,r2)) in enumerate(zip(profile,profile[1:])):
            tube(b+f"/Tower/SectionEdges/Edge{index}_{i}",(r1*cos(a),r1*sin(a),z1),
                 (r2*cos(a),r2*sin(a),z2),.007,polished)
    fitting(b+"/Tower/SightGlass/Seat",(.05,-.369,1.69),(0,-1,0),.081,.062,.04,gasket)
    fitting(b+"/Tower/SightGlass/Rim",(.05,-.39,1.69),(0,-1,0),.091,.062,.022,polished,8)
    tube(b+"/Tower/SightGlass/Window",(.05,-.394,1.69),(.05,-.397,1.69),.062,glass)
    fitting(b+"/Tower/SightGlass/ServicePort",(-.21,-.274,1.49),(-.6,-.8,0),.060,.034,.029,satin,6)
    UsdGeom.Imageable(stage.GetPrimAtPath(b+"/Tower/SightGlass")).MakeInvisible()
    vessel(b+"/Tower/AirDisperser",0,0,[(2.34,.103),(2.39,.124),(2.45,.124),(2.52,.075)],steel,thickness=.008)
    fitting(b+"/Tower/Nozzle/DisperserRing",(0,0,2.303),(0,0,1),.108,.041,.012,satin,8)
    for vane in range(12):
        angle = vane * 2*pi/12
        tube(f"{b}/Tower/Nozzle/DisperserVane{vane}",(.047*cos(angle),.047*sin(angle),2.30),
             (.098*cos(angle+.28),.098*sin(angle+.28),2.318),.004,polished)
    tube(b+"/Tower/Nozzle/Body",(0,0,2.278),(0,0,2.47),.027,polished)
    vessel(b+"/Tower/Nozzle/Tip",0,0,[(NOZZLE_TIP,.010),(2.25,.018),(2.267,.030),(2.285,.031),(2.293,.027)],brass,thickness=.003)
    fitting(b+"/Tower/Nozzle/Union",(0,0,2.447),(0,0,1),.043,.026,.019,polished)
    tube(b+"/Tower/PowderOutlet",(0,0,.32),(0,0,.50),.058,steel)
    tube(b+"/Tower/PowderDrum",(0,0,.152),(0,0,.34),.108,satin)
    fitting(b+"/Tower/DrumClamp",(0,0,.329),(0,0,1),.116,.095,.015,polished)

    # Agitated feed vessel and metering pump on the left skid.
    feed_x=-1.46
    tube(b+"/Feed/Tank",(feed_x,.15,.32),(feed_x,.15,.88),.222,steel)
    tube(b+"/Feed/Lid",(feed_x,.15,.87),(feed_x,.15,.93),.235,polished)
    fitting(b+"/Feed/LidClamp",(feed_x,.15,.885),(0,0,1),.245,.200,.016,satin,8)
    tube(b+"/Feed/Agitator",(feed_x,.15,.93),(feed_x,.15,1.04),.072,blue)
    for i,(dx,dy) in enumerate([(-.13,-.11),(.13,-.11),(0,.15)]):
        tube(b+f"/Feed/Leg{i}",(feed_x+dx,.15+dy,.13),(feed_x+dx,.15+dy,.37),.020,satin)
    tube(b+"/Feed/SightTube",(feed_x,-.079,.415),(feed_x,-.079,.76),.014,teal)
    for i,z in enumerate((.415,.76)):
        tube(f"{b}/Feed/LevelGauge/Union{i}",(feed_x,-.04,z),(feed_x,-.095,z),.022,polished)
    for i in range(5):
        box(f"{b}/Feed/LevelGauge/Mark{i}",(feed_x+.031,-.08,.45+.06*i),(.019,.006,.003),polished)
    tube(b+"/Feed/Pump",(-1.18,-.32,.26),(-.83,-.32,.26),.105,blue)
    tube(b+"/Feed/PumpHead",(-.91,-.32,.26),(-.79,-.32,.26),.077,polished)
    for i in range(7):
        x = -1.145+.028*i
        fitting(f"{b}/Feed/PumpFins/F{i}",(x,-.32,.26),(1,0,0),.109,.101,.007,blue)
    fitting(b+"/Feed/PumpOutletClamp",(-.778,-.32,.26),(1,0,0),.043,.020,.016,satin,4)
    tube(b+"/Feed/PumpLamp",(-1.0,-.42,.28),(-1.0,-.45,.28),.035,lamp_idle)
    pipe(b+"/Feed/Suction",[(feed_x,-.065,.40),(feed_x,-.32,.40),(feed_x,-.32,.26),(-1.18,-.32,.26)],.023,steel)
    pipe(b+"/Feed/LiquidLine",[(-.78,-.32,.26),(-.55,-.32,.26),(-.55,-.32,2.61),(0,-.32,2.61),(0,0,2.61),(0,0,2.45)],.016,blue)
    pipe(b+"/Feed/AtomizingAir",[(-.79,.38,.30),(-.53,.38,.30),(-.53,.38,2.59),(.037,.38,2.59),
                                (.037,.02,2.59),(.037,.02,2.41)],.013,teal)
    box(b+"/Feed/AirRegulator",(-.80,.38,.30),(.19,.12,.15),satin)
    tube(b+"/Feed/AirRegulatorKnob",(-.80,.38,.37),(-.80,.38,.425),.040,graphite)
    tube(b+"/Feed/PressureGauge/Case",(-.79,.316,.327),(-.79,.282,.327),.038,satin)
    tube(b+"/Feed/PressureGauge/Dial",(-.79,.28,.327),(-.79,.276,.327),.032,coated)
    box(b+"/Feed/PressureGauge/Pointer",(-.791,.273,.337),(.003,.002,.020),graphite,32)

    # Fresh air flows from the raised electric heater to the top disperser.
    box(b+"/HotAir/Housing",(-1.16,.17,1.88),(.83,.54,.43),satin)
    box(b+"/HotAir/AccessPanel",(-1.16,-.104,1.88),(.73,.016,.360),frame)
    box(b+"/HotAir/Intake",(-1.62,.17,1.88),(.08,.48,.38),polished)
    for i in range(7):
        box(b+f"/HotAir/IntakeFin{i}",(-1.668,.17,1.73+i*.048),(.022,.425,.019),graphite)
    for i,path in enumerate(HEATER_BANDS):
        box(b+"/"+path,(-1.42+i*.17,-.106,1.88),(.12,.020,.28),lamp_idle)
    for i,x in enumerate((-1.48,-.83)):
        for j,y in enumerate((-.03,.36)):
            box(b+f"/HotAir/Frame{i}{j}",(x,y,.94),(.046,.045,1.62),satin)
    pipe(b+"/HotAir/SupplyDuct",[(-.73,.17,1.9),(-.63,.17,1.9),(-.63,.17,2.71),
                                 (-.28,.17,2.71),(-.12,.17,2.65),(0,0,2.52)],.069,steel)
    tube(b+"/HotAir/InletSensor",(-.63,.095,2.59),(-.63,.026,2.59),.022,teal)
    fitting(b+"/HotAir/DuctFlange",(-.63,.17,2.59),(0,0,1),.095,.068,.022,polished,6)

    # Route exhaust through a tangential cyclone inlet and downstream filter.
    pipe(b+"/Recovery/DirtyAirDuct",EXHAUST_PATH,.04,steel)
    tube(b+"/Recovery/OutletSensor",(.57,0,1.29),(.57,-.092,1.29),.019,teal)
    cyclone_profile=[(.65,.032),(1.46,.175),(1.95,.175),(2.01,.148)]
    vessel(b+"/Recovery/Cyclone",1.23,.07,cyclone_profile,steel,thickness=.007)
    tube(b+"/Recovery/CycloneLid",(1.23,.07,1.979),(1.23,.07,2.015),.151,polished)
    for i,z in enumerate((1.46,1.94)):
        tube(b+f"/Recovery/CycloneBand{i}",(1.23,.07,z-.014),(1.23,.07,z+.014),.182,polished)
    tube(b+"/Recovery/VortexFinder",(1.23,.07,1.98),(1.23,.07,2.14),.053,polished)
    tube(b+"/Recovery/CycloneDischarge",(1.23,.07,.43),(1.23,.07,.66),.041,polished)
    tube(b+"/Recovery/CycloneDrum",(1.23,.07,.155),(1.23,.07,.435),.137,satin)
    tube(b+"/Recovery/DrumLid",(1.23,.07,.415),(1.23,.07,.445),.144,polished)
    fitting(b+"/Recovery/CycloneFlange",(1.23,.07,1.973),(0,0,1),.192,.166,.023,polished,10)
    fitting(b+"/Recovery/CycloneDrumClamp",(1.23,.07,.423),(0,0,1),.152,.124,.016,satin)
    fitting(b+"/Recovery/ExhaustUnion",(1.23,.07,2.218),(0,0,1),.061,.039,.021,polished,5)
    for y in (-.066,.205):
        box(f"{b}/Recovery/DrumLatch{'Front' if y<0 else 'Rear'}",(1.27,y,.403),(.054,.023,.056),satin)
    for i,x in enumerate((1.00,1.46)):
        box(b+f"/Recovery/CycloneStand{i}",(x,.07,.79),(.043,.045,1.33),satin)
    box(b+"/Recovery/FilterHousing",(1.72,.07,1.79),(.36,.34,.65),steel)
    box(b+"/Recovery/FilterCover",(1.72,-.111,1.79),(.29,.022,.49),graphite)
    for i in range(9):
        box(b+f"/Recovery/FilterPleat{i}",(1.601+i*.029,-.127,1.79),(.010,.015,.409),satin)
    for i,x in enumerate((1.57,1.87)):
        for j,z in enumerate((1.527,2.052)):
            tube(f"{b}/Recovery/FilterFastener{i}_{j}",(x,-.115,z),(x,-.131,z),.011,polished)
    pipe(b+"/Recovery/DifferentialPressure/HighLine",[(1.564,.025,1.49),(1.50,.025,1.49),(1.50,-.16,1.60),
         (1.54,-.16,1.81)],.009,blue)
    pipe(b+"/Recovery/DifferentialPressure/LowLine",[(1.564,.025,2.02),(1.52,.025,2.02),(1.52,-.16,1.90),
         (1.54,-.16,1.84)],.009,teal)
    box(b+"/Recovery/DifferentialPressure/Transmitter",(1.54,-.166,1.825),(.086,.049,.080),coated)
    pipe(b+"/Recovery/CleanAirDuct",CLEAN_AIR_PATH,.04,steel)
    tube(b+"/Recovery/FanHousing",(2.19,.015,1.78),(2.19,-.22,1.78),.163,frame)
    tube(b+"/Recovery/FanRim",(2.19,-.22,1.78),(2.19,-.243,1.78),.15,satin)
    rotor = b+"/Recovery/ExhaustFan"
    xf(rotor,(2.19,-.255,1.78),"Y")
    tube(rotor+"/Hub",(0,-.02,0),(0,.02,0),.039,polished)
    for i in range(6):
        a = i*pi/3
        box(rotor+f"/Blade{i}",(.079*sin(a),0,.079*cos(a)),(.040,.021,.115),satin,i*60+22)
    fitting(b+"/Recovery/FanGuard/Ring",(2.19,-.294,1.78),(0,-1,0),.159,.148,.012,polished,6)
    for i in range(-3,4):
        z = i*.035
        span = (.145**2-z**2)**.5
        tube(f"{b}/Recovery/FanGuard/Grille{i+3}",(2.19-span,-.297,1.78+z),(2.19+span,-.297,1.78+z),.0027,satin)
    tube(b+"/Recovery/FanMotor",(2.19,.044,1.78),(2.19,.259,1.78),.093,blue)
    box(b+"/Recovery/FanStand",(2.19,.16,.95),(.057,.076,1.62),frame)

    box(b+"/Controls/Housing",(.64,-.33,1.02),(.31,.21,.52),coated)
    box(b+"/Controls/Door",(.64,-.442,1.02),(.292,.018,.496),satin)
    box(b+"/Controls/DisplayBezel",(.64,-.457,1.15),(.252,.018,.142),graphite)
    box(b+"/Controls/Display",(.64,-.471,1.15),(.217,.011,.111),blue)
    box(b+"/Controls/DoorLatch",(.759,-.457,1.05),(.022,.026,.061),polished)
    tube(b+"/Controls/EmergencyStop/Base",(.725,-.451,1.012),(.725,-.475,1.012),.033,brass)
    tube(b+"/Controls/EmergencyStop/Button",(.725,-.474,1.012),(.725,-.497,1.012),.021,
         UsdShade.Material(stage.GetPrimAtPath("/World/Materials/AlarmRed")))
    for name,x in [("SCR",.59),("Alarm",.69)]:
        tube(b+f"/Controls/{name}",(x,-.45,.96),(x,-.478,.96),.015,lamp_idle)
    for i in range(4):
        box(b+f"/Controls/Key{i}",(.545+i*.061,-.44,.903),(.035,.014,.039),satin)

    for name,count in FLOW_POINTS.items():
        points = UsdGeom.Points.Define(stage,b+"/Flows/"+name)
        points.CreatePointsAttr(Vt.Vec3fArray(count, Gf.Vec3f(0)))
        points.CreateWidthsAttr(Vt.FloatArray([.014]*count))
        points.SetWidthsInterpolation(UsdGeom.Tokens.vertex)
        color = {"Mist":(.46,.84,1.0),"DryingAir":(.11,.85,1.0),"Exhaust":(.43,.77,.82),"Powder":(1,.68,.23)}[name]
        points.CreateDisplayColorPrimvar(UsdGeom.Tokens.constant).Set([Gf.Vec3f(*color)])
        mat = {"Mist":UsdShade.Material(stage.GetPrimAtPath("/World/Materials/MistLight")),
               "DryingAir":teal,"Exhaust":teal,"Powder":amber}[name]
        bind(points,mat)
        points.MakeInvisible()

    define_cameras(stage)
    dome=UsdLux.DomeLight.Define(stage,"/World/Ambient")
    dome.CreateIntensityAttr(550)
    for name,pos,power,rad in [("Key",(-3,-4,6),2600,1.2),("Fill",(3,-3,4),1750,1.6),("Rim",(1,3,5),2950,1.2)]:
        lamp = UsdLux.SphereLight.Define(stage,"/World/"+name)
        lamp.CreateIntensityAttr(power)
        lamp.CreateRadiusAttr(rad)
        UsdGeom.Xformable(lamp).AddTranslateOp().Set(Gf.Vec3d(*pos))
    stage.GetRootLayer().Export(str(output))
    return output


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--output",type=Path,default=OUTPUT)
    print(build(parser.parse_args().output))

