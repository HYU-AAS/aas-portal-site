import base64
from copy import deepcopy
import json
import re
from urllib.error import HTTPError
from urllib.request import HTTPRedirectHandler, Request, build_opener

KPI_RECORD = "Segments.InternalSegmentKPI.Records.KPIRecord"
KPI_MAPPING_MODEL = "AssetInterfacesMappingConfiguration"
SIMULATED_INPUT = "LastSimulatedKpiInput"
EQUIPMENT_RECORD = "Segments.InternalSegment.Records.Record__00__"
RUNTIME = "TwinRuntime"
RUNTIME_TYPES = {
    "Source": "string", "Phase": "string", "SessionId": "string", "BatchId": "string",
    "Kind": "string", "ObservedAt": "dateTime", "Sequence": "long", "SampleSeconds": "double",
    "InletTemperature": "double", "OutletTemperature": "double", "FeedRate": "double",
    "ExhaustFrequency": "double", "Progress": "double", "Fan": "boolean", "Alarm": "boolean",
    "Heater1": "boolean", "Heater2": "boolean", "Heater3": "boolean", "SCR": "boolean",
    "PowderPurge": "boolean",
}


class NoRedirect(HTTPRedirectHandler):
    def redirect_request(self, *args, **kwargs):
        return None


def runtime_collection(values):
    properties = []
    for name, xsd_type in RUNTIME_TYPES.items():
        item = {"modelType": "Property", "idShort": name, "valueType": f"xs:{xsd_type}"}
        if values.get(name) is not None:
            item["value"] = primitive(values[name])
        properties.append(item)
    return {"modelType": "SubmodelElementCollection", "idShort": RUNTIME, "value": properties}


def encoded(identifier):
    return base64.urlsafe_b64encode(identifier.encode()).decode().rstrip("=")


def primitive(value):
    if isinstance(value, bool):
        return str(value).lower()
    return str(value)


def fields(node):
    return {item["idShort"]: item for item in (node.get("value") or []) if item.get("idShort")}


class BaSyx:
    def __init__(self, root, settings, catalog):
        self.base = (settings.get("AAS_URL") or f"http://127.0.0.1:{settings['AAS_PORT']}").rstrip("/")
        self.token = settings.get("AAS_TOKEN")
        self.ids = catalog["submodels"]
        self.catalog = catalog
        baseline = json.loads((root / "aas/environment.json").read_text(encoding="utf-8"))
        self.models = {model["idShort"]:model for model in baseline["submodels"]}

    def call(self, path, method="GET", body=None, content_type="application/json", timeout=4):
        data = body if isinstance(body, bytes) else None if body is None else json.dumps(body).encode()
        headers = {"Content-Type": content_type}
        if self.token and method not in {"GET", "HEAD"}:
            headers["Authorization"] = f"Bearer {self.token}"
        req = Request(self.base + path, method=method, data=data, headers=headers)
        with build_opener(NoRedirect()).open(req, timeout=timeout) as response:
            raw = response.read()
            return json.loads(raw) if raw and response.headers.get_content_type() == "application/json" else raw

    def sm(self, name):
        return f"/submodels/{encoded(self.ids[name])}"

    def locate(self, model, path):
        node = self.models[model]
        for part in path.split("."):
            node = next(item for item in node.get("submodelElements", node.get("value", [])) if item.get("idShort") == part)
        return node

    def put_collection(self, model, path, updates):
        collection = deepcopy(self.locate(model, path))
        for element in collection["value"]:
            name = element["idShort"]
            if name in updates:
                value = updates[name]
                if value is None:
                    element.pop("value", None)
                else:
                    element["value"] = primitive(value)
        self.call(f"{self.sm(model)}/submodel-elements/{path}", "PUT", collection)

    def patch(self, model, path, value):
        self.call(f"{self.sm(model)}/submodel-elements/{path}/$value", "PATCH", primitive(value))

    def kpi_mappings(self):
        """Read the live Source references, Lua and Sink for the known KPI outputs."""
        result = {}
        models = {identifier: name for name, identifier in self.ids.items()}
        expected = {spec["name"]: spec["sink"] for spec in self.catalog["kpis"]}

        def reference_path(element):
            ref = element["value"]
            submodel, *elements = ref["keys"]
            parts = [part["value"] for part in elements]
            if (ref["type"] != "ModelReference" or submodel["type"] != "Submodel" or not elements
                    or elements[-1]["type"] != "Property"
                    or not all(re.fullmatch(r"[A-Za-z][A-Za-z0-9_]*", part) for part in parts)):
                raise ValueError("Expected a reference to a Property")
            return ".".join([models[submodel["value"]], *parts])

        path = self.sm(KPI_MAPPING_MODEL) + "/submodel-elements/MappingConfigurations"
        try:
            mappings = self.call(path, timeout=2)
        except HTTPError as error:
            if error.code != 404:
                raise
            return result
        for mapping in mappings.get("value") or []:
            parts = fields(mapping)
            try:
                (sink,) = parts["Sinks"]["value"]
                sink = fields(sink)
                name = sink["SinkId"]["value"]
            except (KeyError, ValueError, TypeError):
                continue
            if not isinstance(name, str) or name not in expected:
                continue
            if name in result:
                result[name] = {"error": "InvalidMapping"}
                continue
            try:
                if reference_path(sink["Sink"]) != expected[name]:
                    raise ValueError("Unexpected KPI sink")
                sources = [fields(source) for source in parts["Sources"]["value"]]
                inputs = {source["SourceId"]["value"]: reference_path(source["Source"]) for source in sources}
                if len(inputs) != len(sources) or not all(isinstance(key, str) for key in inputs):
                    raise ValueError("Duplicate KPI input")
            except (KeyError, ValueError, TypeError):
                result[name] = {"error": "InvalidMapping"}
                continue
            try:
                blob = parts["Transformation"]["value"]
                if not blob or len(blob) > 32768:
                    raise ValueError("Invalid Lua size")
                code = base64.b64decode(blob, validate=True).decode("utf-8")
            except (KeyError, ValueError, TypeError):
                result[name] = {"error": "InvalidFormula"}
                continue
            result[name] = {"inputs": inputs, "code": code}
        return result

    def kpi_input(self, source_path, default):
        model, path = source_path.split(".", 1)
        endpoint = f"{self.sm(model)}/submodel-elements/{path}"
        try:
            prop = self.call(endpoint, timeout=2)
        except HTTPError as error:
            if error.code != 404:
                raise
            return None, None, False
        if prop.get("modelType") != "Property":
            return None, None, False

        qualifiers = prop.get("qualifiers") or []
        marker = next((item for item in qualifiers if item["type"] == SIMULATED_INPUT), None)
        current = prop.get("value")
        auto = marker["value"] == current if marker else current is None
        if auto and default is not None and default != current:
            stamp = {"type": SIMULATED_INPUT, "kind": "ValueQualifier",
                     "valueType": prop["valueType"], "value": default}
            prop["qualifiers"] = [item for item in qualifiers if item["type"] != SIMULATED_INPUT] + [stamp]
            prop["value"] = default
            self.call(endpoint, "PUT", prop, timeout=2)
            prop = self.call(endpoint, timeout=2)
            auto = prop.get("value") == default
        return prop.get("value"), prop["valueType"], auto

    def apply_live(self, message, values):
        od = "OperationalData"
        measurements = {}
        for signal in self.catalog["signals"]:
            key = signal["idShort"]
            if key in values and values[key] is not None:
                path = signal["path"].split("/",1)[1].replace("/",".")
                measurements[path] = values[key]
        batch = message["batch_id"]
        moment = message["observed_at"]
        fields = {"BatchId":batch, "ProcessStartTimestamp":message["batch_started_at"], "LastUpdateTimestamp":moment,
                  "ActiveProcessId":self.catalog["recipe_process_id"], "RecipeId":self.catalog["settings"]["DryingRecipeId"],
                  "ProcessProgressRate":message["progress"], "OperationMode":"Automatic",
                  "AlarmStatus":"AlarmActive" if message["alarm"] else "NoAlarm",
                  "AlarmCode":"SIM_DO_MISMATCH" if message["do_fault"] else "SIM_TEMP_LIMIT" if message["alarm"] else "NONE"}
        measurements.update({f"CurrentOperation.JobContext.{name}":value for name,value in fields.items()})
        measurements.update({"ThermalProcess.ChamberConditions.ChamberTemperatureActual":message["chamber"],
                             "AirHandlingOperation.AirflowControl.FanRunState":"Running" if message["fan"] else "Stopped",
                             "ExhaustOperation.ExhaustFlow.ExhaustFanRunState":"Running" if message["exhaust_hz"] > 0 else "Stopped"})
        by_group = {}
        for path, value in measurements.items():
            group, name = path.rsplit(".", 1)
            by_group.setdefault(group, {})[name] = value
        for group, updates in by_group.items():
            self.put_collection(od, group, updates)
        runtime = {
            "Source": message["source"], "Phase": message["phase"], "SessionId": message["session_id"],
            "BatchId": batch, "Kind": message["kind"], "ObservedAt": moment, "Sequence": message["seq"],
            "SampleSeconds": message["expected_seconds"], "Progress": message["progress"],
            "InletTemperature": values.get("InletAirTemperatureActual"),
            "OutletTemperature": values.get("OutletAirTemperatureActual"), "FeedRate": message.get("feed_lph"),
            "ExhaustFrequency": message["exhaust_hz"], "Fan": message["fan"], "Alarm": message["alarm"],
            "Heater1": values.get("Heater1RunningState"), "Heater2": values.get("Heater2RunningState"),
            "Heater3": values.get("Heater3RunningState"), "SCR": values.get("SCRRunningState"),
            "PowderPurge": message.get("purging_powder", False),
        }
        self.call(self.sm(od) + "/submodel-elements/" + RUNTIME, "PUT", runtime_collection(runtime))

    def apply(self, message, values, groups, update_kpi):
        equipment_record = {signal["recordIdShort"]: values[signal["idShort"]] for signal in self.catalog["signals"]}
        equipment_record.update({"Time01": message["observed_at"], "BatchIdRecord": message["batch_id"],
                                 "LastUpdateTimestampRecord": message["observed_at"],
                                 "ProcessProgressRateRecord": message["progress"],
                                 "ChamberTemperatureActualRecord": message["chamber"]})
        self.put_collection("TimeSeries", EQUIPMENT_RECORD, equipment_record)
        self.patch("TimeSeries", "Segments.InternalSegment.RecordCount", 1)
        if update_kpi:
            self.apply_kpi(message, groups[-1] if groups else [])
        if not message.get("aas_direct"):
            self.apply_live(message, values)

    def apply_kpi(self, message, aggregation):
        from kpi import sim_utc
        record = {}
        for spec in self.catalog["kpis"]:
            name = spec["name"]
            record[name] = None
            record[name + "Status"] = "OutsideAggregation" if aggregation else "AwaitingData"
        record.update(dict.fromkeys(("Time01", "KPIWindowStart", "KPIWindowEnd", "WorkCenterID", "WorkOrderID",
                                     "AggregationPeriod", "AggregationKey")))
        if aggregation:
            first = aggregation[0]
            observed = first["calculated_at"].isoformat()
            record.update({"Time01":observed, "KPIWindowStart":sim_utc(first["sim_from"]),
                           "KPIWindowEnd":sim_utc(first["sim_to"]), "WorkCenterID":message["equipment_id"],
                           "WorkOrderID":first["batch_id"], "AggregationPeriod":first["period"],
                           "AggregationKey":first["aggregation_key"]})
            for row in aggregation:
                name = row["kpi"]
                if name not in record:
                    continue
                record[name] = row["value"]
                record[name + "Status"] = row["status"]
        endpoint = self.sm("TimeSeries") + "/submodel-elements/" + KPI_RECORD
        existing = fields(self.call(endpoint))
        for name, value in record.items():
            prop = existing[name]
            value = primitive(value) if value is not None else None
            if prop.get("value") == value:
                continue
            if value is None:
                prop.pop("value", None)
            else:
                prop["value"] = value
            self.call(endpoint + "." + name, "PUT", prop)
        self.patch("TimeSeries", "Segments.InternalSegmentKPI.RecordCount", int(bool(aggregation)))
        if aggregation:
            for key in ("StartTime", "EndTime"):
                self.patch("TimeSeries", "Segments.InternalSegmentKPI." + key, record["Time01"])

