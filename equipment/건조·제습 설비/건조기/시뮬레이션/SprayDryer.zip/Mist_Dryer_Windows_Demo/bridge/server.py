"""Loopback JSON ingest, transactional PostgreSQL storage, and single-writer AAS sync."""
from datetime import datetime
from http.server import BaseHTTPRequestHandler, HTTPServer
import hmac
import json
import logging
import math
import os
from pathlib import Path
import sys
import threading
from uuid import UUID

import psycopg
from psycopg.rows import dict_row
from psycopg.types.json import Jsonb

from basyx import BaSyx
from kpi import Engine

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT / "isaac"))
from process import config

SETTINGS = {**config(), **os.environ}
CATALOG = json.loads((ROOT / "aas/runtime.json").read_text(encoding="utf-8"))
SIGNALS = CATALOG["signals"]
KINDS = {"session_start", "batch_start", "phase_enter", "sample", "batch_complete",
         "alarm_on", "alarm_clear", "do_invalid", "do_recovered", "session_end"}
LOCK = 715407201
log = logging.getLogger("mist")
STOP = threading.Event()


def connect(reader=False):
    return psycopg.connect(host=SETTINGS.get("PG_HOST", "127.0.0.1"), port=int(SETTINGS["PG_PORT"]), dbname="mist_dryer",
                           user="dryer_reader" if reader else "dryer_owner",
                           password=SETTINGS["READER_PASSWORD" if reader else "PG_PASSWORD"],
                           row_factory=dict_row, connect_timeout=2,
                           options="-c search_path=dryer_twin,public -c statement_timeout=5000")


def latest_replay(db):
    completed = db.execute("""
        SELECT s.session_id, s.last_sim_seconds, s.ended_at,
               (SELECT count(*) FROM batch_runs b
                WHERE b.session_id=s.session_id AND b.completed_at IS NOT NULL) AS batches
        FROM sessions s
        WHERE s.equipment_id=%s AND s.ended_at IS NOT NULL AND s.last_sim_seconds>0
          AND EXISTS (SELECT 1 FROM messages m WHERE m.session_id=s.session_id AND m.seq=0
                      AND m.payload->>'process_mode'='continuous_spray')
          AND EXISTS (SELECT 1 FROM messages m WHERE m.session_id=s.session_id AND m.seq=s.last_seq
                      AND m.kind='session_end' AND m.phase='Complete')
        ORDER BY s.ended_at DESC LIMIT 1
    """, (CATALOG["equipment_id"],)).fetchone()
    if completed is None:
        return None
    frames = db.execute("""
        WITH samples AS (
            SELECT DISTINCT ON (floor(sim_seconds / %(bucket)s)) seq, sim_seconds, phase, kind, payload
            FROM messages
            WHERE session_id=%(session)s AND kind='sample'
            ORDER BY floor(sim_seconds / %(bucket)s), seq
        ), frames AS (
            SELECT * FROM samples
            UNION ALL
            SELECT seq, sim_seconds, phase, kind, payload FROM messages
            WHERE session_id=%(session)s AND kind IN ('phase_enter','session_end')
        )
        SELECT jsonb_build_object(
            'seconds', sim_seconds, 'Phase', phase, 'Kind', kind,
            'Fan', payload->'fan', 'Alarm', payload->'alarm', 'SCR', payload->'scr',
            'PowderPurge', payload->'purging_powder', 'FeedRate', payload->'feed_lph',
            'ExhaustFrequency', payload->'exhaust_hz',
            'InletTemperature', payload->'values'->'InletAirTemperatureActual'->'value',
            'OutletTemperature', payload->'values'->'OutletAirTemperatureActual'->'value',
            'Heater1', payload->'heaters'->0, 'Heater2', payload->'heaters'->1,
            'Heater3', payload->'heaters'->2) AS frame
        FROM frames ORDER BY sim_seconds, seq
    """,
        {"bucket": max(1, completed["last_sim_seconds"] / 900), "session": completed["session_id"]}).fetchall()
    return {"session": str(completed["session_id"]), "batches": completed["batches"],
            "endedAt": completed["ended_at"].isoformat(), "frames": [row["frame"] for row in frames]}


class Rejected(ValueError):
    pass


def finite(number):
    return type(number) in {int,float} and math.isfinite(number)


def validate(msg):
    if msg["kind"] not in KINDS or msg["source"] not in {"isaac_sim","mock"} or msg["equipment_id"] != CATALOG["equipment_id"]:
        raise Rejected("Unknown equipment, source or message kind")
    session = str(UUID(msg["session_id"]))
    if session != msg["session_id"] or type(msg["seq"]) is not int or msg["seq"] < 0:
        raise Rejected("Invalid session or sequence")
    if (msg["kind"] == "session_start") != (msg["seq"] == 0):
        raise Rejected("Invalid initial event")
    for key in ("observed_at","batch_started_at"):
        moment = datetime.fromisoformat(msg[key])
        if moment.utcoffset() is None or moment.utcoffset().total_seconds() != 0:
            raise Rejected("Timestamp must be UTC")
    if (not finite(msg["sim_seconds"]) or msg["sim_seconds"] < 0 or not finite(msg["progress"]) or
            not 0 <= msg["progress"] <= 100 or not finite(msg["expected_seconds"]) or
            not .1 <= msg["expected_seconds"] <= 60):
        raise Rejected("Invalid clock or progress")
    if msg["phase"] not in {"Preheat","Dry","Cool","Complete"} or msg["kpi_inputs"] not in {"synthetic","missing","zero","wrong_unit"}:
        raise Rejected("Invalid phase or KPI scenario")
    if not msg["batch_id"].startswith(session[:8] + "-B") or not msg["batch_id"].split("-B")[-1].isdigit():
        raise Rejected("Bad batch identity")
    if msg.get("process_mode") == "continuous_spray":
        if not finite(msg["feed_lph"]) or msg["feed_lph"] < 0:
            raise Rejected("Invalid simulated feed rate")
        if not finite(msg["target_batch_seconds"]) or msg["target_batch_seconds"] <= 0:
            raise Rejected("Invalid continuous lot duration")
    for key in ("chamber","moisture","exhaust_hz"):
        if not finite(msg[key]):
            raise Rejected("Invalid process value")
    for key in ("alarm","do_fault","fan"):
        if type(msg[key]) is not bool:
            raise Rejected("Invalid process flag")


def decode(msg, last):
    values = {}
    quality = {}
    for sig in SIGNALS:
        key = sig["idShort"]
        if sig["sourceSignalType"] == "DO":
            on, off = (msg["raw_do"][signal] for signal in sig["sourceSignals"])
            if type(on) is not int or type(off) is not int or on not in {0,1} or off not in {0,1}:
                raise Rejected("DO values must be integer bits")
            if on == off:
                values[key] = last.get(key)
                quality[key] = {"status":"InvalidDoPair", "pair":[on,off], "held":values[key]}
            else:
                values[key] = bool(on)
        else:
            item = msg["values"][key]
            if item["unit"] != sig["unit"] or not finite(item["value"]):
                raise Rejected("Invalid engineering value or unit for " + key)
            values[key] = item["value"]
    return values, quality


def ingest(msg, engine, api):
    validate(msg)
    sid, seq, kind, equipment = (msg[key] for key in ("session_id","seq","kind","equipment_id"))
    batch = msg["batch_id"]
    sim = msg["sim_seconds"]
    at = msg["observed_at"]
    with connect() as db:
        db.execute("SELECT pg_advisory_xact_lock(%s)", (LOCK,))
        existing = db.execute("SELECT payload FROM messages WHERE session_id=%s AND seq=%s", (sid,seq)).fetchone()
        if existing is not None:
            if existing["payload"] != msg:
                raise Rejected("Duplicate sequence has a different message")
            item = db.execute("SELECT payload FROM aas_outbox WHERE session_id=%s AND seq=%s", (sid, seq)).fetchone()
            active = db.execute("SELECT 1 FROM active_session WHERE equipment_id=%s AND session_id=%s",
                                (equipment, sid)).fetchone()
            return "duplicate", item["payload"]["values"], bool(active)
        session = db.execute("SELECT * FROM sessions WHERE session_id=%s", (sid,)).fetchone()
        active = db.execute("""SELECT s.* FROM active_session a JOIN sessions s USING(session_id)
                             WHERE a.equipment_id=%s""", (equipment,)).fetchone()
        is_active = kind == "session_start" or bool(active and active["session_id"] == UUID(sid))
        if kind == "session_start":
            db.execute("SELECT pg_advisory_xact_lock(%s)", (LOCK+1,))
            if session is not None or (active and datetime.fromisoformat(at) <= active["started_at"]):
                raise Rejected("Older session")
            db.execute("""INSERT INTO sessions(session_id,equipment_id,source,started_at,expected_seconds,last_seq)
                         VALUES (%s,%s,%s,%s,%s,%s)""", (sid,equipment,msg["source"],at,msg["expected_seconds"],seq))
            db.execute("""INSERT INTO active_session VALUES (%s,%s)
                         ON CONFLICT(equipment_id) DO UPDATE SET session_id=EXCLUDED.session_id""", (equipment,sid))
        else:
            if session is None or session["ended_at"] is not None or session["source"] != msg["source"]:
                raise Rejected("Unknown or ended session")
            if seq != session["last_seq"]+1 or sim < session["last_sim_seconds"]:
                raise Rejected("Sequence gap or simulated clock reversal")
            last_clock = db.execute("SELECT observed_at FROM messages WHERE session_id=%s AND seq=%s",
                                    (sid,seq-1)).fetchone()["observed_at"]
            if datetime.fromisoformat(at) < last_clock:
                raise Rejected("Observed clock reversal")
            db.execute("UPDATE sessions SET last_seq=%s,last_sim_seconds=%s WHERE session_id=%s",(seq,sim,sid))
        db.execute("""INSERT INTO messages(session_id,seq,observed_at,sim_seconds,batch_id,kind,phase,progress,payload)
                      VALUES(%s,%s,%s,%s,%s,%s,%s,%s,%s)""",
                   (sid,seq,at,sim,batch,kind,msg["phase"],msg["progress"],Jsonb(msg)))
        last = db.execute("SELECT payload FROM aas_outbox WHERE session_id=%s ORDER BY seq DESC LIMIT 1", (sid,)).fetchone()
        values, quality = decode(msg, last["payload"]["values"] if last else {})
        if kind == "sample":
            cols = [values[sig["idShort"]] for sig in SIGNALS]
            op,h1,h2,h3,scr,*analog = cols
            i1,i2,i3,i4,o1,o2,o3,o4,hz1,hz2 = analog
            db.execute("""INSERT INTO telemetry(session_id,seq,batch_id,observed_at,sim_seconds,phase,progress,
                       inlet_pv,inlet_sv,inlet_high,inlet_low,outlet_pv,outlet_sv,outlet_high,outlet_low,chamber_temp,moisture,
                       exhaust_pv,exhaust_sv,operating,heater1,heater2,heater3,scr,alarm,quality,values)
                       VALUES(%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)""",
                       (sid,seq,batch,at,sim,msg["phase"],msg["progress"],i1,i2,i3,i4,o1,o2,o3,o4,
                        msg["chamber"],msg["moisture"],hz1,hz2,op,h1,h2,h3,scr,msg["alarm"],Jsonb(quality),Jsonb(values)))
        else:
            db.execute("INSERT INTO process_events VALUES (%s,%s,%s,%s,%s,%s,%s,%s)",
                       (sid,seq,batch,at,sim,kind,msg["phase"],Jsonb({"quality":quality,"alarm":msg["alarm"]})))
        kpi_changed = False
        if kind == "batch_start":
            inserted = db.execute("""INSERT INTO batch_runs(session_id,batch_id,started_at,started_sim_seconds)
                                    VALUES (%s,%s,%s,%s) ON CONFLICT DO NOTHING RETURNING batch_id""",
                                  (sid,batch,at,sim)).fetchone()
            if not inserted:
                raise Rejected("Batch start already exists")
            save_kpis(db,sid,batch,msg,engine,api,sim,active=is_active)
            kpi_changed = True
        elif kind == "batch_complete":
            run = db.execute("""UPDATE batch_runs SET completed_at=%s,completed_sim_seconds=%s,
                               duration_sim_seconds=%s-started_sim_seconds WHERE session_id=%s AND batch_id=%s
                               AND completed_at IS NULL RETURNING started_sim_seconds""",(at,sim,sim,sid,batch)).fetchone()
            if not run:
                raise Rejected("Batch is missing or already complete")
            previous = db.execute("""SELECT started_sim_seconds,duration_sim_seconds FROM batch_runs WHERE session_id=%s
                                    AND batch_id<>%s AND completed_at IS NOT NULL ORDER BY completed_sim_seconds DESC LIMIT 1""",
                                  (sid,batch)).fetchone()
            save_kpis(db,sid,batch,msg,engine,api,run["started_sim_seconds"],
                      tuple(previous.values()) if previous else None, active=is_active)
            kpi_changed = True
        elif kind == "session_end":
            db.execute("UPDATE sessions SET ended_at=%s WHERE session_id=%s",(at,sid))
        payload = {"values":values,"kpi_changed":kpi_changed or kind=="session_start"}
        db.execute("INSERT INTO aas_outbox(session_id,seq,payload) VALUES (%s,%s,%s)",(sid,seq,Jsonb(payload)))
    return "accepted", values, is_active


def save_kpis(db, sid, batch, msg, engine, api, start, previous=None, *, active):
    operating_seconds = None
    if previous is not None and int(batch.rsplit("B", 1)[1]) % 2 == 0:
        shift_start, _ = previous
        operating_seconds = db.execute("""
            WITH run_intervals AS (
                SELECT sim_seconds, payload->>'running' = 'true' AS running,
                       lead(sim_seconds, 1, %(end)s) OVER (ORDER BY seq) AS next_second
                FROM messages
                WHERE session_id=%(session)s AND sim_seconds >= %(start)s AND seq <= %(seq)s
            )
            SELECT COALESCE(sum(next_second - sim_seconds) FILTER (WHERE running), 0) AS seconds
            FROM run_intervals
        """, {"session": sid, "start": shift_start, "end": msg["sim_seconds"], "seq": msg["seq"]}).fetchone()["seconds"]
    for row in engine.collect(api, msg, start, previous, operating_seconds, active=active):
        db.execute("""INSERT INTO kpi_results(session_id,aggregation_key,kpi,batch_id,period,sim_from,sim_to,value,unit,status,inputs,input_source,trigger_seq)
                   VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s) ON CONFLICT DO NOTHING""",
                   (sid,row["aggregation_key"],row["kpi"],batch,row["period"],row["sim_from"],row["sim_to"],row["value"],
                    row["unit"],row["status"],Jsonb(row["inputs"]),"basyx",msg["seq"]))


def sync():
    api = BaSyx(ROOT, SETTINGS, CATALOG)
    while not STOP.is_set():
        try:
            with connect() as db:
                db.execute("SELECT pg_advisory_xact_lock(%s)", (LOCK+1,))
                row = db.execute("""SELECT a.session_id,o.seq,o.payload,m.payload AS message FROM active_session a
                            JOIN aas_outbox o USING(session_id) JOIN messages m USING(session_id,seq)
                            WHERE o.covered_at IS NULL ORDER BY o.seq DESC LIMIT 1""").fetchone()
                if row:
                    sid,seq = row["session_id"],row["seq"]
                    msg = row["message"]
                    change = db.execute("""SELECT 1 FROM aas_outbox WHERE session_id=%s AND seq<=%s
                                          AND covered_at IS NULL AND (payload->>'kpi_changed')::boolean LIMIT 1""",(sid,seq)).fetchone()
                    groups = []
                    if change:
                        pending = db.execute("""SELECT k.* FROM kpi_results k JOIN aas_outbox o
                             ON o.session_id=k.session_id AND o.seq=k.trigger_seq
                             WHERE k.session_id=%s AND k.trigger_seq<=%s AND o.covered_at IS NULL
                             ORDER BY k.trigger_seq,k.calculated_at,k.kpi""",(sid,seq)).fetchall()
                        grouped = {}
                        for kpi in pending:
                            grouped.setdefault(kpi["aggregation_key"], []).append(kpi)
                        groups = list(grouped.values())
                    try:
                        api.apply(msg,row["payload"]["values"],groups,change)
                    except Exception as error:
                        detail = f"{type(error).__name__}: {error}"[:300]
                        db.execute("UPDATE aas_outbox SET attempts=attempts+1,last_error=%s WHERE session_id=%s AND seq=%s",
                                   (detail,sid,seq))
                        log.warning("BaSyx retry seq=%s %s",seq,detail)
                    else:
                        if change or not msg.get("aas_direct"):
                            db.execute("UPDATE aas_outbox SET applied_at=clock_timestamp(), attempts=attempts+1,last_error=NULL WHERE session_id=%s AND seq=%s",
                                       (sid,seq))
                        db.execute("""UPDATE aas_outbox SET covered_at=clock_timestamp()
                                      WHERE session_id=%s AND seq<=%s AND covered_at IS NULL""",(sid,seq))
        except psycopg.Error as error:
            log.warning("Outbox DB retry %s",type(error).__name__)
        STOP.wait(.35)


class Handler(BaseHTTPRequestHandler):
    engine = Engine(CATALOG)
    api = BaSyx(ROOT, SETTINGS, CATALOG)

    def reply(self, code, payload):
        data = json.dumps(payload, ensure_ascii=False).encode()
        self.send_response(code)
        self.send_header("Content-Type","application/json; charset=utf-8")
        self.send_header("Content-Length",str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def do_GET(self):
        if self.path not in {"/health", "/replay"}:
            self.reply(404,{"message":"unknown endpoint"})
            return
        try:
            with connect(reader=True) as db:
                if self.path == "/replay":
                    replay = latest_replay(db)
                    if replay is None:
                        self.reply(404, {"message": "No completed spray-dryer run"})
                    else:
                        self.reply(200, replay)
                    return
                row = db.execute("SELECT count(*) FROM sessions").fetchone()
            self.reply(200,{"database":"ready","sessions":row["count"]})
        except psycopg.Error:
            self.reply(503,{"database":"unavailable"})

    def do_POST(self):
        if self.path != "/ingest":
            self.reply(404,{"message":"unknown endpoint"})
            return
        token = SETTINGS.get("AAS_TOKEN")
        authorized = hmac.compare_digest(self.headers.get("X-Dryer-Key", ""), SETTINGS["INGEST_KEY"])
        if token:
            authorized |= hmac.compare_digest(self.headers.get("Authorization", ""), f"Bearer {token}")
        if not authorized:
            self.reply(401,{"message":"invalid ingest key"})
            return
        try:
            length = int(self.headers.get("Content-Length","0"))
            if not 0 < length <= 32_768:
                raise Rejected("Invalid body size")
            msg = json.loads(self.rfile.read(length))
            result, values, active = ingest(msg,self.engine,self.api)
        except (KeyError,TypeError,ValueError) as error:
            self.reply(422,{"message":str(error)})
        except psycopg.Error:
            log.exception("Ingest transaction failed")
            self.reply(503,{"message":"database error, retry"})
        except OSError as error:
            log.warning("KPI source BaSyx unavailable: %s", error)
            self.reply(503,{"message":"BaSyx error, retry"})
        else:
            self.reply(200,{"result":result, "values":values, "active":active})

    def log_message(self, fmt, *args):
        if str(args[1]) != "200":
            log.info(fmt,*args)

    def setup(self):
        super().setup()
        self.connection.settimeout(5)


def main():
    logging.basicConfig(level=logging.INFO,format="%(asctime)s %(levelname)s %(message)s")
    port = int(SETTINGS["BRIDGE_PORT"])
    server = HTTPServer((SETTINGS.get("BRIDGE_HOST", "127.0.0.1"),port),Handler)
    server.timeout = .5
    worker = threading.Thread(target=sync,daemon=True)
    worker.start()
    log.info("Mist Dryer ingest listening at http://127.0.0.1:%d",port)
    try:
        while not (ROOT / ".runtime/stop-bridge").exists():
            server.handle_request()
    finally:
        STOP.set()
        worker.join(8)
        server.server_close()


if __name__ == "__main__":
    main()

