"""Read live AIMC KPI inputs and evaluate their Lua transformations."""
from datetime import datetime, timedelta, timezone
import math

from lupa.lua54 import LuaError, LuaRuntime

GROUPS = {
    "WorkOrder": ("PlanAdherence",),
    "Shift": ("OutputRate", "UnitsPerHour", "LaborProductivity", "FirstPassYield", "DefectRate",
              "OverallEquipmentEffectiveness", "AvailabilityRate", "PerformanceEfficiency", "QualityRate", "TotalDowntime"),
    "Batch": ("TactTimeVariance", "ReworkRate", "ScrapRate", "ProcessCapabilityCpk"),
    "Lot": ("ThroughputTime",),
    "Current": ("WIPQuantity",),
    "SimulatedMonth": ("MeanTimeBetweenFailures", "MeanTimeToRepair"),
}
UNITS = {"UnitsPerHour":"EA/h", "LaborProductivity":"EA/(person·h)", "TactTimeVariance":"s", "ThroughputTime":"min",
         "WIPQuantity":"EA", "DefectRate":"ppm", "ProcessCapabilityCpk":"1",
         "MeanTimeBetweenFailures":"h", "MeanTimeToRepair":"min", "TotalDowntime":"min"}
SIM_EPOCH = datetime(2026, 1, 1, tzinfo=timezone.utc)
DEMO_SHIFT_WORKERS = 2
QMS = {"GQ", "FirstPassGoodQuantity", "FirstPassInspectedQuantity", "NonconformingQuantity",
       "ReworkProcessedQuantity", "ScrapMaterialQuantity", "QualityUSL", "QualityLSL", "QualityMean", "QualitySigma"}
CMMS = {"ReliabilityOperatingTime", "FailureCount", "RepairTime", "RepairedFailureCount", "FaultStopTime"}


def sim_utc(seconds):
    return (SIM_EPOCH + timedelta(seconds=seconds)).isoformat().replace("+00:00", "Z")


def duration(seconds):
    return f"PT{seconds:g}S"


def input_unit(name, field):
    if field["type"] == "xs:duration":
        return "ISO8601"
    if field["type"] == "xs:dateTime":
        return "UTC"
    if name in {"FailureCount", "RepairedFailureCount"}:
        return "count"
    if name.startswith("Quality") and name != "QuantityUnit":
        return "% moisture"
    return "EA"


class Engine:
    def __init__(self, catalog):
        self.specs = {spec["name"]: spec for spec in catalog["kpis"]}
        self.lua = LuaRuntime(register_eval=False, register_builtins=False, max_memory=2_000_000,
                              attribute_filter=self.deny_python)
        self.run = self.lua.eval("""function(code, sources, key)
            local env = {assert=assert, type=type, tonumber=tonumber, math={
                min=math.min, max=math.max, abs=math.abs, floor=math.floor,
                huge=math.huge, tointeger=math.tointeger
            }}
            local budget = 0
            debug.sethook(function()
                budget = budget + 1000
                assert(budget < 100000, 'AIMC execution budget exceeded')
            end, '', 1000)
            local ok, result = pcall(function()
                local program = load(code, 'AIMC formula', 't', env)
                if program == nil then return false end
                program()
                return env.aimc_main(sources)[key]
            end)
            debug.sethook()
            if not ok then error(result) end
            return result
        end""")

    @staticmethod
    def deny_python(obj, key, setting):
        raise AttributeError("Python object access is disabled")

    def evaluate(self, name, input_values, code=None, required=None):
        if required is None:
            required = self.specs[name]["inputs"]
        if any(key not in input_values or input_values[key]["value"] is None for key in required):
            return None, "MissingInput"
        if any(item["unit"] != item.get("expected_unit", item["unit"]) for item in input_values.values()):
            return None, "InvalidUnit"
        if code is None:
            spec = self.specs[name]
            code = spec["code"]
            if any(input_values[key]["unit"] != input_unit(key, field) for key, field in spec["inputs"].items()):
                return None, "InvalidUnit"
        try:
            value = self.run(code, self.lua.table_from({key:item["value"] for key,item in input_values.items()}), name)
            if value is False:
                return None, "InvalidFormula"
            if isinstance(value, bool) or not isinstance(value, (float, int)) or not math.isfinite(value):
                return None, "InvalidResult"
            return value, "Valid"
        except (LuaError, MemoryError) as error:
            return None, "InvalidInput:" + str(error).splitlines()[0].split(": ")[-1][:100]

    def example(self, name):
        return {key:{"value":field["example"], "unit":input_unit(key, field), "source":"type_regression"}
                for key,field in self.specs[name]["inputs"].items()}

    def collect(self, api, message, batch_start, previous=None, operating_seconds=None, *, active=True):
        live = api.kpi_mappings()
        end = message["sim_seconds"]
        batch = message["batch_id"]
        number = int(batch.rsplit("B",1)[1])
        windows = [("Current", end, end)] if message["kind"] == "batch_start" else [
            ("Batch", batch_start, end), ("Lot", batch_start, end), ("WorkOrder", batch_start, end)]
        if message["kind"] == "batch_complete":
            if previous is not None and number % 2 == 0:
                windows.append(("Shift", previous[0], end))
            if number == 1:
                windows.insert(0, ("SimulatedMonth", 0, 31*86400))
        for period, start, finish in windows:
            observed = {}
            context = {"LotEnteredAt": (sim_utc(start), "synthetic_mes"),
                       "LotCompletedAt": (sim_utc(finish), "synthetic_mes")}
            if period == "Shift":
                apt = end - batch_start + previous[1]
                context.update(OperatingTime=(duration(operating_seconds) if operating_seconds is not None else None,
                                              "simulated_run_state"),
                               PBT=(duration(finish-start), "synthetic_mes"),
                               PRI=("PT65S", "synthetic_mes"), PQ=("76", "synthetic_mes"), GQ=("72", "synthetic_qms"),
                               PlannedOutputQuantity=("80", "synthetic_mes"), CompletedOutputQuantity=("76", "synthetic_mes"),
                               APWT=(duration((finish-start) * DEMO_SHIFT_WORKERS), "synthetic_mes"),
                               FirstPassGoodQuantity=("72", "synthetic_qms"),
                               FirstPassInspectedQuantity=("76", "synthetic_qms"), NonconformingQuantity=("4","synthetic_qms"),
                               FaultStopTime=("PT0S","synthetic_cmms"), ChangeoverStopTime=(duration(max(0, finish-start-apt)),"synthetic_mes"),
                               MicroStopTime=("PT0S","synthetic_mes"), MaterialWaitTime=("PT0S","synthetic_mes"))
            if period == "SimulatedMonth":
                context.update(ReliabilityOperatingTime=("PT320H","synthetic_cmms"), RepairTime=("PT55M","synthetic_cmms"),
                               FailureCount=("3","synthetic_cmms"))
            for name in GROUPS[period]:
                spec = self.specs[name]
                values = {}
                mapping = live.get(name, {"error": "InvalidMapping"})
                for key, path in mapping.get("inputs", {}).items():
                    field = spec["inputs"].get(key, {})
                    origin = "synthetic_qms" if key in QMS else "synthetic_cmms" if key in CMMS else "synthetic_mes"
                    default, origin = context.get(key, (field.get("example"), origin))
                    if path not in observed:
                        observed[path] = api.kpi_input(path, default if active and field.get("path") == path else None)
                    value, value_type, auto = observed[path]
                    source = "basyx" if not auto else "basyx_" + origin
                    unit = input_unit(key, {"type": value_type})
                    expected_unit = input_unit(key, field) if field else unit
                    if message["kpi_inputs"] == "missing" and key != "OperatingTime":
                        value = None
                        source = "test_missing"
                    if message["kpi_inputs"] == "zero" and key in {"TargetTaktTime", "OperatingTime", "PBT", "FailureCount"}:
                        value = "PT0S" if value_type == "xs:duration" else "0"
                        source = "test_zero"
                    if message["kpi_inputs"] == "wrong_unit" and key == "QuantityUnit":
                        unit = "kg"
                        source = "test_wrong_unit"
                    values[key] = {"value":value,"unit":unit,"expected_unit":expected_unit,
                                   "source":source,"path":path}
                if "error" in mapping:
                    result, status = None, mapping["error"]
                else:
                    result, status = self.evaluate(name, values, mapping["code"], mapping["inputs"])
                yield {"aggregation_key":f"{period}:{batch}", "period":period, "sim_from":start, "sim_to":finish,
                       "kpi":name, "value":result, "status":status, "unit":UNITS.get(name,"%"), "inputs":values}

