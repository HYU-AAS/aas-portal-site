import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';

const el = id => document.getElementById(id);
const container = el('scene');
const status = el('status');
const phaseButtons = [...document.querySelectorAll('button[data-phase]')];
const scene = new THREE.Scene();
scene.background = new THREE.Color(0x151e28);
const camera = new THREE.PerspectiveCamera(37, 1, 0.03, 70);
camera.up.set(0, 0, 1);
const viewButtons = ['auto', 'section', 'nozzle', 'exterior'];
let selection = 'auto';
let currentView;
let freeView = false;
let controls;
let live;
let displayed;
let reachable = true;
let replay;
const parts = new Map();
const flows = new Map();
const truth = value => value === 'true' || value === true;
const phaseLabels = {Preheat: '예열', Dry: '연속 분무', Cool: '냉각', Complete: '완료'};
const viewLabels = {section: '장비 단면', heat: '히터·열풍', nozzle: '노즐·건조탑', exhaust: '사이클론·배기', exterior: '장비 외관'};
const colors = {Mist: 0x82d9ff, DryingAir: 0x3cbdff, Exhaust: 0x65dce0, Powder: 0xffbb61};
const replaySpeed = 60;

function clock(seconds) {
  const whole = Math.floor(seconds);
  return Math.floor(whole / 60) + ':' + String(whole % 60).padStart(2, '0');
}

function applyView(name, view) {
  if (currentView === name) return;
  currentView = name;
  camera.position.fromArray(view.eye);
  controls.target.fromArray(view.target);
  camera.fov = view.fov;
  camera.updateProjectionMatrix();
  controls.update();
  el('view-name').textContent = viewLabels[name];
  for (const [path, part] of parts) {
    if (/^Tower\/(Section|SectionBands\/|SectionEdges\/)/.test(path)) part.visible = view.section;
    if (/^Tower\/(Shell|ExteriorBands\/|SightGlass\/)/.test(path)) part.visible = !view.section;
  }
}

function geometry(shape) {
  if (shape.kind === 'Cube') return new THREE.BoxGeometry(shape.size, shape.size, shape.size);
  if (shape.kind === 'Sphere') return new THREE.SphereGeometry(shape.radius, 16, 12);
  if (shape.kind === 'Cylinder') {
    return new THREE.CylinderGeometry(shape.radius, shape.radius, shape.height, 24).rotateX(Math.PI / 2);
  }
  const mesh = new THREE.BufferGeometry();
  mesh.setAttribute('position', new THREE.Float32BufferAttribute(shape.points.flat(), 3));
  mesh.setIndex(shape.indices);
  mesh.computeVertexNormals();
  return mesh;
}

let active = false;
function showReadings(state, label, running, updateView) {
  displayed = state;
  active = running;
  status.dataset.live = !replay && active;
  status.dataset.replay = Boolean(replay);
  const text = active && truth(state?.Alarm) ? label + ' · 알람' : label;
  if (status.textContent !== text) status.textContent = text;
  for (const button of phaseButtons) {
    if (button.dataset.phase === state?.Phase) button.setAttribute('aria-current', 'step');
    else button.removeAttribute('aria-current');
  }
  for (const [id, key, digits, unit] of [['inlet', 'InletTemperature', 1, '°C'],
    ['outlet', 'OutletTemperature', 1, '°C'], ['feed', 'FeedRate', 2, 'L/h'], ['exhaust', 'ExhaustFrequency', 1, 'Hz']]) {
    const value = state?.[key];
    el(id).textContent = value == null || value === '' ? '—' : Number(value).toFixed(digits) + ' ' + unit;
  }
  updateView();
}

function showLive(updateView) {
  const fresh = Date.now() - Date.parse(live?.ObservedAt) <= Math.max(10000, Number(live?.SampleSeconds) * 10000);
  const running = Boolean(reachable && fresh && live.Kind !== 'session_end');
  let label = 'AAS 연결 끊김';
  if (reachable) {
    if (!live?.ObservedAt) label = '샘플 대기';
    else if (live.Kind === 'session_end' && live.Phase !== 'Complete') label = '발행 종료';
    else if (!fresh && live.Kind !== 'session_end') label = '마지막 수신 단계 · ' + (phaseLabels[live.Phase] ?? live.Phase);
    else label = '현재 단계 · ' + (phaseLabels[live.Phase] ?? live.Phase);
  }
  showReadings(live, label, running, updateView);
}

async function poll(updateView) {
  try {
    const response = await fetch('./live', {cache: 'no-store', signal: AbortSignal.timeout(4000)});
    if (!response.ok) throw Error(response.status);
    live = await response.json();
    reachable = true;
  } catch {
    reachable = false;
  }
  if (!replay) showLive(updateView);
  setTimeout(() => poll(updateView), 1000);
}

function showReplay(updateView) {
  const slider = el('replay-time');
  const {frames, end, time} = replay;
  const nextIndex = frames.findIndex(frame => frame.seconds > time);
  const frame = frames[nextIndex < 0 ? frames.length - 1 : Math.max(0, nextIndex - 1)];
  el('pause').disabled = time >= end;
  el('pause').textContent = replay.paused ? '계속 재생' : '일시정지';
  slider.value = time;
  slider.setAttribute('aria-valuetext', clock(time) + ' 모의 시간');
  el('replay-clock').value = clock(time) + ' / ' + clock(end);
  if (replay.frame !== frame) {
    replay.frame = frame;
    showReadings(frame, '재생 단계 · ' + phaseLabels[frame.Phase], frame.Kind !== 'session_end', updateView);
  }
}

async function start() {
  const renderer = new THREE.WebGLRenderer({antialias: true});
  renderer.setPixelRatio(Math.min(devicePixelRatio, 2));
  const canvas = renderer.domElement;
  container.append(canvas);
  controls = new OrbitControls(camera, canvas);
  controls.enableDamping = true;
  controls.minPolarAngle = THREE.MathUtils.degToRad(5);
  controls.maxPolarAngle = THREE.MathUtils.degToRad(89);
  controls.rotateSpeed = 0.65;
  controls.maxDistance = 14;
  controls.minDistance = 0.45;
  canvas.addEventListener('pointermove', event => {
    if (freeView || !canvas.hasPointerCapture(event.pointerId) || !(event.buttons & 1)) return;
    if (!(event.movementX || event.movementY)) return;
    freeView = true;
    el('view-name').textContent = '자유 시점';
    for (const name of viewButtons) el(name).setAttribute('aria-pressed', 'false');
  });
  new ResizeObserver(() => {
    renderer.setSize(container.clientWidth, container.clientHeight, false);
    camera.aspect = container.clientWidth / container.clientHeight;
    camera.updateProjectionMatrix();
  }).observe(container);
  scene.add(new THREE.HemisphereLight(0xe5f6ff, 0x526274, 2.1));
  for (const [position, intensity] of [[[-3, -4, 6], 3], [[3, 2, 4], 2]]) {
    const light = new THREE.DirectionalLight(0xffffff, intensity);
    light.position.fromArray(position);
    scene.add(light);
  }
  const floor = new THREE.GridHelper(20, 40, 0x3d5362, 0x273b4c);
  floor.rotation.x = Math.PI / 2;
  scene.add(floor);

  const response = await fetch('./model.json?revision=detail');
  if (!response.ok) throw Error('model ' + response.status);
  const model = await response.json();
  const rotor = new THREE.Group();
  rotor.position.fromArray(model.rotor);
  scene.add(rotor);
  const materialCache = new Map();
  for (const shape of model.shapes) {
    const opacity = shape.opacity ?? 1;
    const key = [shape.rgb, shape.roughness, shape.metalness, opacity].join(',');
    const dynamic = model.indicators.includes(shape.path);
    let material = dynamic ? undefined : materialCache.get(key);
    if (!material) {
      material = new THREE.MeshStandardMaterial({
        color: new THREE.Color(...shape.rgb), side: THREE.DoubleSide,
        roughness: shape.roughness, metalness: shape.metalness,
        opacity, transparent: opacity < 1, depthWrite: opacity === 1,
      });
      if (!dynamic) materialCache.set(key, material);
    }
    const part = new THREE.Mesh(geometry(shape), material);
    const matrix = new THREE.Matrix4().fromArray(shape.matrix);
    const rotating = shape.path.startsWith('Recovery/ExhaustFan/');
    if (rotating) model.rotor.forEach((axis, i) => matrix.elements[12 + i] -= axis);
    part.applyMatrix4(matrix);
    (rotating ? rotor : scene).add(part);
    parts.set(shape.path, part);
  }
  let randomSeed = 9329;
  const random = () => {
    randomSeed = (Math.imul(randomSeed, 1664525) + 1013904223) >>> 0;
    return randomSeed / 4294967296;
  };
  for (const [key, spec] of Object.entries(model.streams)) {
    const points = new THREE.BufferGeometry();
    const position = new THREE.BufferAttribute(new Float32Array(spec.count * 3), 3);
    points.setAttribute('position', position);
    const material = new THREE.PointsMaterial({
      size: key === 'Mist' ? 0.023 : 0.028, color: colors[key], opacity: 0.86, transparent: true
    });
    const cloud = new THREE.Points(points, material);
    cloud.frustumCulled = false;
    cloud.visible = false;
    scene.add(cloud);
    const particles = Array.from({length: spec.count}, () => [random(), random() * 2 * Math.PI, Math.sqrt(random())]);
    flows.set(key, {cloud, position, paths: spec.paths, particles, offset: 0});
  }
  function updateView() {
    if (freeView) return;
    const finished = displayed?.Kind === 'session_end';
    const name = selection === 'auto'
      ? (finished ? 'exterior' : model.phaseViews[displayed?.Phase] ?? 'section')
      : selection;
    applyView(name, model.views[name]);
  }
  for (const name of viewButtons) {
    el(name).onclick = () => {
      freeView = false;
      selection = name;
      currentView = undefined;
      for (const key of viewButtons) el(key).setAttribute('aria-pressed', key === selection);
      updateView();
    };
  }
  const replayButton = el('replay');
  const returnLive = el('return-live');
  const slider = el('replay-time');
  const replayMessage = el('replay-message');
  const playbackButtons = [replayButton, ...phaseButtons];
  let requestNumber = 0;
  let recording;

  function showReplayMessage(message) {
    replayMessage.hidden = !message;
    replayMessage.textContent = message;
  }

  function setLoading(loading) {
    for (const button of playbackButtons) button.disabled = loading;
  }

  async function playFrom(phase) {
    const request = ++requestNumber;
    try {
      if (!recording) {
        setLoading(true);
        showReplayMessage('완료 기록 불러오는 중');
        const response = await fetch('./replay', {cache: 'no-store', signal: AbortSignal.timeout(6000)});
        if (request !== requestNumber) return;
        if (response.status === 404) {
          showReplayMessage('재생할 완료 기록이 없습니다.');
          return;
        }
        if (!response.ok) throw Error(response.status);
        const result = await response.json();
        if (request !== requestNumber) return;
        recording = result;
      }
      const {frames, batches} = recording;
      const start = phase ? frames.find(frame => frame.Phase === phase && frame.Kind === 'phase_enter') : frames[0];
      if (!start) {
        showReplayMessage('완료 기록에 이 단계가 없습니다.');
        return;
      }
      replay = {frames, end: frames.at(-1).seconds, time: start.seconds, paused: false};
      slider.max = replay.end;
      el('replay-controls').hidden = false;
      returnLive.hidden = false;
      showReplayMessage('최근 완료 기록 · ' + batches + '배치 · ' + replaySpeed + '배속');
      el('auto').click();
      showReplay(updateView);
    } catch (error) {
      if (request === requestNumber) showReplayMessage('완료 기록을 불러오지 못했습니다. 다시 시도해 주세요.');
    } finally {
      if (request === requestNumber) setLoading(false);
    }
  }

  setLoading(false);
  replayButton.onclick = () => playFrom();
  for (const button of phaseButtons) button.onclick = () => playFrom(button.dataset.phase);
  returnLive.onclick = () => {
    requestNumber++;
    replay = undefined;
    recording = undefined;
    returnLive.hidden = true;
    setLoading(false);
    el('replay-controls').hidden = true;
    showReplayMessage('');
    showLive(updateView);
  };
  el('pause').onclick = () => {
    replay.paused = !replay.paused;
    showReplay(updateView);
  };
  slider.oninput = () => {
    replay.time = Number(slider.value);
    showReplay(updateView);
  };
  updateView();
  poll(updateView);
  let previous = performance.now();
  let airPhase;
  renderer.setAnimationLoop(now => {
    const elapsed = Math.max(0, (now - previous) / 1000);
    if (replay && !replay.paused && replay.time < replay.end) {
      replay.time = Math.min(replay.end, replay.time + Math.min(elapsed, 0.25) * replaySpeed);
      showReplay(updateView);
    }
    const delta = replay?.paused ? 0 : Math.min(0.1, elapsed);
    previous = now;
    const fan = active && truth(displayed?.Fan) && displayed?.Phase !== 'Complete';
    const exhaust = fan && Number(displayed?.ExhaustFrequency) > 0;
    const mist = active && displayed?.Phase === 'Dry' && Number(displayed?.FeedRate ?? 1) > 0 && !truth(displayed?.Alarm);
    const enabled = {Mist: mist, DryingAir: fan, Exhaust: exhaust,
      Powder: mist || (active && displayed?.Phase === 'Cool' && truth(displayed?.PowderPurge))};
    const phase = displayed?.Phase;
    const airStyle = model.airStyles[phase] ?? model.airStyles.Dry;
    if (airPhase !== phase) {
      flows.get('DryingAir').cloud.material.color.setRGB(...airStyle.rgb);
      airPhase = phase;
    }
    if (exhaust) rotor.rotation.y += delta * Number(displayed.ExhaustFrequency) * 0.2269;
    const lamps = ['Heater1', 'Heater2', 'Heater3', 'SCR', 'Alarm'].map(key => active && truth(displayed?.[key]));
    lamps.push(mist);
    model.indicators.forEach((path, index) => {
      const lamp = parts.get(path);
      if (lamp) lamp.material.emissive.setHex(lamps[index] ? (index < 3 || index === 4 ? 0xff521e : 0x05dc8b) : 0x000000);
    });
    for (const [key, stream] of flows) {
      const {cloud, position, paths, particles} = stream;
      cloud.visible = enabled[key] && (model.views[currentView].section || key === 'Exhaust');
      if (!cloud.visible) continue;
      let speed = model.streamSpeeds[key];
      if (key === 'DryingAir') speed = airStyle.speed;
      if (key === 'Exhaust') speed *= Number(displayed.ExhaustFrequency) / 45;
      stream.offset = (stream.offset + delta * speed) % 1;
      for (let i = 0; i < position.count; i++) {
        const [offset, azimuth, radialSpread] = particles[i];
        const ratio = (stream.offset + offset) % 1;
        const path = paths[i % paths.length];
        const at = ratio * (path.length - 1);
        const j = Math.min(path.length - 2, Math.floor(at));
        const [x, y, z] = path[j].map((v, axis) => v + (path[j + 1][axis] - v) * (at - j));
        if (key === 'Mist' || key === 'DryingAir') {
          const angle = azimuth + ratio * 0.72;
          const radius = Math.hypot(x, y) * (key === 'Mist' ? radialSpread : 1);
          position.setXYZ(i, Math.cos(angle) * radius, Math.sin(angle) * radius, z);
        } else {
          position.setXYZ(i, x, y, z);
        }
      }
      position.needsUpdate = true;
    }
    controls.update();
    renderer.render(scene, camera);
  });
}

start().catch(error => {
  console.error(error);
  status.textContent = '3D 뷰어를 열 수 없습니다';
});
