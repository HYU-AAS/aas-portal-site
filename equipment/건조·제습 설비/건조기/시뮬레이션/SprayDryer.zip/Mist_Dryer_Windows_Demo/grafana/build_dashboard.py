import argparse
import base64
from html import escape
import json
from pathlib import Path

from signal_cards import EXHAUST, INLET_AXIS, SESSION, TEMPERATURES, setting_card, write_dashboard

ROOT = Path(__file__).resolve().parents[1]
parser = argparse.ArgumentParser()
parser.add_argument("aas_port", nargs="?", default="3015")
parser.add_argument("--viewer", default="http://127.0.0.1:8092/")
parser.add_argument("--aas-ui")
parser.add_argument("--output", type=Path, default=ROOT / "grafana/dashboards")
args = parser.parse_args()
catalog = json.loads((ROOT / "aas/runtime.json").read_text(encoding="utf-8"))
od = base64.urlsafe_b64encode(catalog["submodels"]["OperationalData"].encode()).decode().rstrip("=")
ds = {"type": "postgres", "uid": "mist-postgres"}
aas_ds = {"type": "yesoreyeram-infinity-datasource", "uid": "aas-infinity"}
sid = f"session_id = {SESSION}"
panels = []


def add(i, title, kind, x, y, w, h, sql=None, unit=None, content=None):
    panel = dict(id=i, title=title, type=kind, gridPos=dict(x=x, y=y, w=w, h=h),
                 fieldConfig=dict(defaults=dict(noValue="데이터 없음"), overrides=[]), options={})
    if sql:
        panel.update(datasource=ds, targets=[dict(refId="A", format="time_series" if kind=="timeseries" else "table",
                                               rawQuery=True, rawSql=sql, editorMode="code", datasource=ds)])
    if unit:
        panel["fieldConfig"]["defaults"]["unit"] = unit
    if kind == "stat":
        panel["options"].update(reduceOptions={"calcs":["lastNotNull"],"fields":"/.*/"}, graphMode="none", textMode="value")
    if content:
        panel["options"]={"mode":"markdown", "content":content}
    panels.append(panel)


def live_panel(i, title, x, width, expression, value_type, unit=None):
    add(i, title, "stat", x, 1, width, 4, unit=unit)
    target = dict(refId="A", datasource=aas_ds, type="json", source="url", format="table", parser="backend",
                  url_options={"method": "GET"}, url=f"http://aas-ro:8089/submodels/{od}/submodel-elements/TwinRuntime/%24value",
                  root_selector='($result := (' + expression + '); {"value": $result})',
                  columns=[dict(selector="value", text=title, type=value_type)])
    panels[-1].update(datasource=aas_ds, targets=[target])
    panels[-1]["options"]["reduceOptions"]["fields"] = "/.*/" if value_type == "string" else ""


def trend(columns):
    return f"SELECT observed_at AS time,{columns} FROM dryer_twin.telemetry WHERE {sid} AND $__timeFilter(observed_at) ORDER BY time"


add(1,"전체 운전지표","row",0,0,24,1)
live_panel(2, "현재 공정 단계", 0, 8,
           'Kind = "session_end" and Phase != "Complete" ? "운전 종료" : '
           '$lookup({"Preheat":"예열","Dry":"연속 분무","Cool":"냉각","Complete":"완료"}, Phase)', "string")
add(12,"완료 작업 수","stat",8,1,8,4,
    f"SELECT count(*) AS completed FROM dryer_twin.batch_runs WHERE {sid} AND completed_at IS NOT NULL", "suffix: 건")
panels[-1]["description"] = "선택한 실행 세션에서 완료 이벤트를 기록한 작업(배치) 수입니다. 대시보드의 시간 범위와 별도로 집계합니다."
panels[-1]["fieldConfig"]["defaults"]["decimals"] = 0
live_panel(5, "AAS 수신 상태", 16, 8,
           'Kind = "session_end" ? "발행 종료" : ($exists(ObservedAt) and ObservedAt != null ? '
           '($age := $millis() - $toMillis(ObservedAt); $s := $number(SampleSeconds); '
           '$age > $max([10000,$s*10000]) ? "수신 중단 · 무응답" : '
           '$age > $max([4000,$s*4000]) ? "데이터 지연" : "실시간 수신") : "샘플 대기")', "string")
add(6,"선택 세션 · 최신 관측 · 수신 지연","table",0,36,24,4,f"""SELECT t.batch_id AS "배치",s.source AS "출처 (합성)",t.observed_at AS "관측 UTC",
   t.ingested_at AS "DB UTC",round(extract(epoch FROM now()-t.observed_at)::numeric,2) AS "지연 s",s.expected_seconds AS "발행 주기 s"
   FROM dryer_twin.sessions s LEFT JOIN LATERAL
   (SELECT * FROM dryer_twin.telemetry WHERE session_id=s.session_id ORDER BY seq DESC LIMIT 1)t ON true WHERE s.{sid}""")
add(7,"입구 온도","timeseries",0,27,12,9,trend(
    'inlet_pv AS "입구 측정값"'),"celsius")
panels[-1]["fieldConfig"]["defaults"].update(custom=dict(INLET_AXIS), decimals=2)
add(22,"출구 온도 · 챔버 참고","timeseries",12,27,12,9,trend(
    'outlet_pv AS "출구 측정값",chamber_temp AS "챔버 측정값"'),"celsius")
for panel, prefix, measured_color in ((panels[-2], "입구", "#ffac68"), (panels[-1], "출구", "#44d1c2")):
    panel["options"]["tooltip"] = {"mode": "multi"}
    series_colors = {f"{prefix} 측정값": measured_color}
    if prefix == "출구":
        series_colors["챔버 측정값"] = "#a7a1b8"
    for name, color in series_colors.items():
        properties = [{"id": "color", "value": {"mode": "fixed", "fixedColor": color}}]
        if name != f"{prefix} 측정값":
            properties.append({"id": "custom.lineStyle", "value": {"fill": "dash", "dash": [5, 4]}})
        panel["fieldConfig"]["overrides"].append({"matcher": {"id": "byName", "options": name}, "properties": properties})
add(8,"배기 인버터 · 주파수","timeseries",0,40,12,8,trend('exhaust_pv AS "측정 주파수"'),"hertz")
status_signals = [(9, "전체 운전", "OperatingState", 0, 4),
                  (23, "히터 1", "Heater1RunningState", 4, 5),
                  (24, "히터 2", "Heater2RunningState", 9, 5),
                  (25, "히터 3", "Heater3RunningState", 14, 5),
                  (26, "SCR", "SCRRunningState", 19, 5)]
add(27, "운전 상태 · 1 운전 / 0 정지", "row", 0, 5, 24, 1)
for panel_id, name, key, x, width in status_signals:
    add(panel_id, name, "stat", x, 6, width, 4,
        f"SELECT (payload->'values'->>'{key}')::boolean::int AS state "
        f"FROM dryer_twin.aas_outbox WHERE {sid} ORDER BY seq DESC LIMIT 1")
    panels[-1]["fieldConfig"]["defaults"].update(decimals=0, color={"mode": "thresholds"},
        thresholds={"mode": "absolute", "steps": [{"value": None, "color": "gray"}, {"value": 1, "color": "green"}]})
add(11, "온도 경보·디지털 신호 이벤트", "table", 12, 40, 12, 8, f"""
    SELECT observed_at AS "시각",
           kind AS "이벤트",
           CASE phase WHEN 'Preheat' THEN '예열' WHEN 'Dry' THEN '연속 분무'
                      WHEN 'Cool' THEN '냉각' WHEN 'Complete' THEN '완료'
                      ELSE '미확인' END AS "공정 단계",
           batch_id AS "배치",
           CASE kind WHEN 'alarm_on' THEN '온도 경보 한계 초과 또는 미달'
                     WHEN 'alarm_clear' THEN '온도 경보 조건 해소'
                     WHEN 'do_invalid' THEN '운전·정지 신호가 같은 값. 마지막 정상 상태 유지'
                     WHEN 'do_recovered' THEN '운전·정지 신호 조합 정상화' END AS "내용"
    FROM dryer_twin.process_events
    WHERE {sid} AND kind IN ('alarm_on','alarm_clear','do_invalid','do_recovered')
    ORDER BY seq DESC LIMIT 40""")
panels[-1]["fieldConfig"]["overrides"] = [
    {"matcher": {"id": "byName", "options": "이벤트"}, "properties": [
        {"id": "custom.cellOptions", "value": {"type": "color-text"}},
        {"id": "custom.width", "value": 148},
        {"id": "mappings", "value": [{"type": "value", "options": {
            "alarm_on": {"text": "온도 경보 발생", "color": "red"},
            "alarm_clear": {"text": "온도 경보 해제", "color": "green"},
            "do_invalid": {"text": "디지털 신호 이상", "color": "red"},
            "do_recovered": {"text": "디지털 신호 복구", "color": "green"},
        }}]},
    ]},
]

work_order = "최근 완료 작업지시"
shift = "최근 완료 교대"
batch = "최근 완료 배치"
lot = "최근 완료 로트"
month = "모의 월간 정비 집계"
production_metrics = (
    (101, "PlanAdherence", "계획 준수율", "percent", 1, work_order, "계획 생산량 대비 양품 수량"),
    (102, "OutputRate", "산출률", "percent", 1, shift, "계획 생산량 대비 생산 완료 수량"),
    (103, "UnitsPerHour", "시간당 생산량", "suffix: 개/시간", 1, shift, "설비 운전 시간당 완료 수량"),
    (104, "LaborProductivity", "노동 생산성", "none", 1, shift, "작업자 투입 공수당 총 생산량"),
    (105, "WIPQuantity", "재공 수량", "suffix: 개", 0, "최근 재공 집계", "누적 투입 수량에서 누적 완료 수량을 뺀 값"),
    (106, "ThroughputTime", "로트 통과 시간", "suffix: 분", 1, lot, "로트 진입부터 완료까지 걸린 시간"),
    (107, "TactTimeVariance", "택트 타임 편차", "none", 1, batch, "샘플 사이클의 실제 시간에서 표준 택트 타임을 뺀 값"),
)
quality_metrics = (
    (111, "QualityRate", "양품률", "percent", 1, shift, "총 생산 수량 중 양품 비율"),
    (112, "FirstPassYield", "초회 합격률", "percent", 1, shift, "최초 검사 수량 중 바로 합격한 비율"),
    (113, "DefectRate", "백만 개당 불량 수", "suffix: 개", 0, shift, "총 생산량 대비 불량 수량을 백만 개 기준으로 환산한 값"),
    (114, "ReworkRate", "재작업률", "percent", 1, batch, "총 생산 수량 대비 재작업 수량"),
    (115, "ScrapRate", "폐기율", "percent", 1, batch, "투입 수량 대비 폐기 수량"),
    (116, "ProcessCapabilityCpk", "공정능력지수", "none", 2, batch, "수분 평균과 분산이 상·하한 규격에 얼마나 여유 있게 들어가는지 나타내는 값"),
)
equipment_metrics = (
    (121, "OverallEquipmentEffectiveness", "설비 종합 효율", "percent", 1, shift, "가동률과 성능 효율, 양품률을 곱한 값"),
    (122, "AvailabilityRate", "설비 가동률", "percent", 1, shift, "계획 부하 시간 중 설비가 실제로 운전한 시간의 비율"),
    (123, "PerformanceEfficiency", "설비 성능 효율", "percent", 1, shift, "표준 사이클 시간과 생산 수량을 곱한 값을 설비 운전 시간으로 나눈 비율"),
    (124, "TotalDowntime", "총 정지 시간", "suffix: 분", 1, shift, "고장·교체·미세 정지·자재 대기 시간 합계"),
    (125, "MeanTimeBetweenFailures", "평균 고장 간격", "suffix: 시간", 1, month, "모의 가동시간을 고장 건수로 나눈 값"),
    (126, "MeanTimeToRepair", "평균 수리 시간", "suffix: 분", 1, month, "총 수리시간을 고장 건수로 나눈 값"),
)
metric_groups = (
    (13, "생산 지표", 48, "#85bcf8", production_metrics, 4),
    (15, "품질 지표", 57, "#6dd8b3", quality_metrics, 3),
    (16, "설비 지표", 66, "#f2be79", equipment_metrics, 3),
)
metric_keys = [metric[1] for *_, metrics, split in metric_groups for metric in metrics]
if len(metric_keys) != len(set(metric_keys)) or set(metric_keys) != {metric["name"] for metric in catalog["kpis"]}:
    raise ValueError("The Korean monitoring cards must cover every AIMC metric exactly once")

for group_id, group_title, y, accent, metrics, split in metric_groups:
    add(group_id, group_title, "row", 0, y, 24, 1)
    for row, cards in enumerate((metrics[:split], metrics[split:])):
        width = 24 // len(cards)
        for col, (panel_id, key, title, unit, decimals, period, detail) in enumerate(cards):
            display = {
                "LaborProductivity": """round(value::numeric, 1)::text ||
                    CASE WHEN unit = 'EA/(person·h)' THEN ' 개/인·시간' ELSE ' 개/시간' END""",
                "TactTimeVariance": """round(value::numeric, 1)::text ||
                    CASE WHEN inputs ? 'ActualCycleTime' THEN ' 초/사이클' ELSE ' 초/배치' END""",
            }.get(key, "value")
            add(panel_id, title, "stat", col * width, y + 1 + row * 4, width, 4,
                f"""SELECT (
                    SELECT {display} FROM dryer_twin.kpi_results
                    WHERE {sid} AND kpi = '{key}'
                    ORDER BY calculated_at DESC, trigger_seq DESC NULLS LAST, aggregation_key DESC LIMIT 1
                ) AS "값" """, unit)
            panels[-1]["description"] = f"{period} 기준입니다. {detail}입니다. 선택한 실행 세션의 최신 값을 표시합니다."
            if key in {"UnitsPerHour", "TactTimeVariance", "WIPQuantity", "LaborProductivity", "OverallEquipmentEffectiveness",
                       "AvailabilityRate", "PerformanceEfficiency", "MeanTimeToRepair"}:
                panels[-1]["description"] += " 이전 실행 기록에는 당시 계산 기준이 적용됩니다."
            panels[-1]["fieldConfig"]["defaults"].update(
                decimals=decimals, color={"mode": "fixed", "fixedColor": accent}, noValue="집계값 없음")
            panels[-1]["options"].update(colorMode="value")

add(21, "3D 디지털 트윈 · AAS 실시간", "text", 0, 10, 24, 17)
panels[-1]["description"] = "전체 재생으로 최근 완료 기록을 처음부터 보거나 단계 버튼으로 원하는 지점부터 재생합니다. 실시간 보기로 현재 상태를 다시 봅니다."
panels[-1]["options"] = {"mode": "html", "content":
    f'<iframe src="{escape(args.viewer, quote=True)}?view=orbit" title="Mist Dryer 3D" style="display:block;width:100%;height:100%;border:0"></iframe>'}
for panel in panels:
    if panel["gridPos"]["y"] >= 36:
        panel["gridPos"]["y"] += 13
add(33, "운전 설정", "row", 0, 36, 24, 1)
temperature_settings = [signal for signal in TEMPERATURES if not signal[1].endswith("_pv")]
for index, (name, column, _, color) in enumerate(temperature_settings):
    panels.append(setting_card(34 + index, name, column, "celsius", color, index % 3 * 8, 37 + index // 3 * 4, 8, 4))
name, column, _, color = EXHAUST[1]
panels.append(setting_card(40, name, column, "hertz", color, 0, 45, 8, 4))
panels.sort(key=lambda panel: (panel["gridPos"]["y"], panel["gridPos"]["x"]))
phase_events = dict(
    name="공정 단계 전환", datasource=ds, enable=True, iconColor="#efb76c",
    target=dict(refId="A", format="table", rawQuery=True, editorMode="code", rawSql=f"""
        SELECT observed_at AS time,
               CASE phase WHEN 'Preheat' THEN '예열 시작' WHEN 'Dry' THEN '분무 시작'
                          WHEN 'Cool' THEN '냉각 시작' WHEN 'Complete' THEN '완료' END AS text,
               '공정 단계 전환' AS tags
        FROM dryer_twin.process_events
        WHERE {sid} AND kind='phase_enter' AND $__timeFilter(observed_at)
        ORDER BY observed_at"""),
)
dashboard = dict(uid="mist-dryer",title="Mist Dryer | 디지털 트윈",schemaVersion=41,timezone="utc",refresh="5s",
                 time={"from":"now-15m","to":"now"},editable=False,panels=panels, tags=["DRYER-SIM-01","합성 데이터"],
                 annotations={"list": [phase_events]},
                 templating={"list":[dict(name="session",label="실행 세션",type="query",datasource=ds,refresh=2,
                    current={"text": "현재 실행 세션", "value": "active"},
                    query="""SELECT label AS __text, value AS __value FROM (
                        SELECT '현재 실행 세션' AS label, 'active' AS value, NULL::timestamptz AS started_at
                        UNION ALL
                        SELECT source||' · '||session_id, session_id::text, started_at FROM dryer_twin.sessions
                    ) AS choices ORDER BY started_at DESC NULLS FIRST""")]},
                 links=[dict(title="수집 신호 20개",type="link",url="/d/mist-dryer-signals"),
                        dict(title="3D 뷰어 열기",type="link",url=args.viewer,targetBlank=True),
                        dict(title="BaSyx AAS Web UI",type="link",url=args.aas_ui or f"http://127.0.0.1:{args.aas_port}",targetBlank=True)])
path = args.output / "dryer.json"
path.parent.mkdir(parents=True,exist_ok=True)
path.write_text(json.dumps(dashboard,ensure_ascii=False,indent=2),encoding="utf-8")

write_dashboard(ROOT, args.output)
