"""Provision Grafana cards for the acquisition channels."""
import json

DATASOURCE = {"type": "postgres", "uid": "mist-postgres"}
SESSION = """COALESCE(NULLIF(NULLIF(${session:sqlstring}, 'active'), '')::uuid,
    (SELECT session_id FROM dryer_twin.active_session WHERE equipment_id = 'DRYER-SIM-01'))"""

INLET_AXIS = {"axisSoftMin": 110, "axisSoftMax": 114}
TEMPERATURES = (
    ("입구 온도 측정값", "inlet_pv", "측정값", "#ffac68"),
    ("입구 온도 설정값", "inlet_sv", "설정값", "#ffcf87"),
    ("입구 온도 경보 상한", "inlet_high", "상한 설정값", "#ff7e84"),
    ("입구 온도 경보 하한", "inlet_low", "하한 설정값", "#f3e28e"),
    ("출구 온도 측정값", "outlet_pv", "측정값", "#44d1c2"),
    ("출구 온도 설정값", "outlet_sv", "설정값", "#8be9d6"),
    ("출구 온도 경보 상한", "outlet_high", "상한 설정값", "#ff7e84"),
    ("출구 온도 경보 하한", "outlet_low", "하한 설정값", "#f3e28e"),
)
EXHAUST = (
    ("배기 인버터 측정 주파수", "exhaust_pv", "측정 주파수", "#6cb9ff"),
    ("배기 인버터 설정 주파수", "exhaust_sv", "설정 주파수", "#9ae4ff"),
)


def series_sql(value, message_payload):
    join = " JOIN dryer_twin.messages m USING (session_id, seq)" if message_payload else ""
    return (f"SELECT t.observed_at AS time, {value} FROM dryer_twin.telemetry t{join}\n"
            f"WHERE t.session_id = {SESSION} AND $__timeFilter(t.observed_at) ORDER BY time, t.seq")


def setting_sql(column):
    return (f"SELECT {column} AS value FROM dryer_twin.telemetry WHERE session_id = {SESSION}\n"
            "AND observed_at <= $__timeTo() ORDER BY observed_at DESC, seq DESC LIMIT 1")


def setting_card(id_, name, column, unit, color, x, y, width, height):
    return number_card(id_, name, "선택한 세션에서 표시 시간 범위의 끝 시점까지 마지막으로 기록된 설정입니다.",
                       setting_sql(column), unit, {"mode": "fixed", "fixedColor": color}, x, y, width, height)


def number_card(id_, name, description, sql, unit, color, x, y, width, height):
    return {
        "id": id_, "title": name, "type": "stat",
        "description": description,
        "gridPos": {"x": x, "y": y, "w": width, "h": height}, "datasource": DATASOURCE,
        "targets": [{
            "refId": "A", "datasource": DATASOURCE, "format": "table", "editorMode": "code",
            "rawQuery": True, "rawSql": sql,
        }],
        "fieldConfig": {
            "defaults": {"unit": unit, "noValue": "수신값 없음", "color": color},
            "overrides": [],
        },
        "options": {"graphMode": "none", "textMode": "value", "colorMode": "value",
                    "reduceOptions": {"calcs": ["lastNotNull"], "fields": ""}},
    }


def card(id_, name, description, x, y, width, *, value, unit, color, message_payload=False):
    field = {
        "displayName": name,
        "unit": unit,
        "decimals": 2,
        "color": {"mode": "fixed", "fixedColor": color},
        "noValue": "수신값 없음",
        "custom": {
            "drawStyle": "line", "lineInterpolation": "linear",
            "lineWidth": 2, "fillOpacity": 12, "showPoints": "never",
            "spanNulls": False, "insertNulls": 4000,
        },
    }
    return {
        "id": id_, "title": name, "type": "timeseries", "description": description,
        "gridPos": {"x": x, "y": y, "w": width, "h": 6}, "datasource": DATASOURCE,
        "targets": [{
            "refId": "A", "datasource": DATASOURCE, "format": "time_series",
            "rawQuery": True, "editorMode": "code", "rawSql": series_sql(value + " AS value", message_payload),
        }],
        "fieldConfig": {"defaults": field, "overrides": []},
        "options": {
            "legend": {"showLegend": True, "displayMode": "list", "placement": "bottom", "calcs": ["lastNotNull"]},
            "tooltip": {"mode": "single", "sort": "none"},
        },
    }


def row(id_, title, y):
    return {"id": id_, "title": title, "type": "row", "collapsed": False, "panels": [],
            "gridPos": {"x": 0, "y": y, "w": 24, "h": 1}}


def write_dashboard(root, output=None):
    mapping = json.loads((root / "aas/runtime.json").read_text(encoding="utf-8"))["signals"]
    do_names = [name for signal in mapping if signal["sourceSignalType"] == "DO" for name in signal["sourceSignals"]]
    if len(set(do_names)) != 10 or len(do_names) != 10:
        raise ValueError("Expected ten unique DO inputs in the acquisition mapping")
    panels = [{
        "id": 1, "type": "text", "title": "수집원 및 조회 방법",
        "gridPos": {"x": 0, "y": 0, "w": 24, "h": 3},
        "options": {"mode": "markdown", "content": (
            "**합성 운전 데이터** · Isaac Sim / mock · 한국 표준시　　"
            "원료 공급량이 늘면 출구 온도는 시차를 두고 내려갑니다. 두 그래프는 같은 시간 범위를 표시합니다."
        )},
    }, row(2, "운전·히터·SCR · 디지털 원신호 10개 (1 활성 / 0 비활성)", 3)]
    for i, name in enumerate(do_names):
        key = name.replace("'", "''")
        sql = (f"SELECT (m.payload->'raw_do'->>'{key}')::smallint AS value\n"
               "FROM dryer_twin.telemetry t JOIN dryer_twin.messages m USING (session_id, seq)\n"
               f"WHERE t.session_id = {SESSION} AND t.observed_at <= $__timeTo()\n"
               "ORDER BY t.observed_at DESC, t.seq DESC LIMIT 1")
        panel = number_card(10+i, name, "선택 시간 범위의 끝 시점까지 마지막으로 기록된 디지털 원신호입니다.",
                            sql, "none", {"mode": "thresholds"}, i % 4 * 6, 4 + i // 4 * 4, 6, 4)
        panel["fieldConfig"]["defaults"].update(decimals=0, thresholds={
            "mode": "absolute", "steps": [{"value": None, "color": "gray"}, {"value": 1, "color": "green"}],
        })
        panels.append(panel)
    panels.append(row(3, "입구·출구 온도 · 공학값 8개 (°C)", 16))
    for i, (name, column, role, color) in enumerate(TEMPERATURES):
        x, y = i % 4 * 6, 17 + i // 4 * 6
        if column.endswith("_pv"):
            panel = card(20+i, name, f"공학 단위 온도 {role}.", x, y, 6,
                         value=f"t.{column}", unit="celsius", color=color)
            if column == "inlet_pv":
                panel["fieldConfig"]["defaults"]["custom"].update(INLET_AXIS)
        else:
            panel = setting_card(20+i, name, column, "celsius", color, x, y, 6, 6)
        panels.append(panel)
    panels.append(row(4, "배기 인버터 · 공학값 2개 (Hz)", 29))
    name, column, role, color = EXHAUST[0]
    panels.append(card(28, name, role, 0, 30, 12, value=f"t.{column}", unit="hertz", color=color))
    name, column, _, color = EXHAUST[1]
    panels.append(setting_card(29, name, column, "hertz", color, 12, 30, 12, 6))
    # Put the linked response plots above the acquisition channels on the same time range.
    for panel in panels[1:]:
        panel["gridPos"]["y"] += 7
    panels[1:1] = [
        row(5, "연속 분무 · 입구 온도, 원료 공급량, 출구 온도", 3),
        card(32, "입구 온도 · 측정값", "연속 분무 중 입구 온도 측정값.", 0, 4, 8,
             value="t.inlet_pv", unit="celsius", color="#ffac68"),
        card(30, "원료 공급량 · 모의값", "연속 분무 모델이 기록한 공급량. 선행 세션은 수신값 없음으로 표시.",
             8, 4, 8, value="(m.payload->>'feed_lph')::double precision", unit="suffix:L/h",
             color="#9dbafc", message_payload=True),
        card(31, "출구 온도 측정값 · 공급량 응답", "원료 공급량이 늘면 지연을 두고 낮아지고, 줄면 올라가는 모의 출구 온도.",
             16, 4, 8, value="t.outlet_pv", unit="celsius", color="#44d1c2"),
    ]
    panels[2]["fieldConfig"]["defaults"]["custom"].update(INLET_AXIS)
    dashboard = {
        "uid": "mist-dryer-signals", "title": "Mist Dryer | 수집 신호 20개",
        "schemaVersion": 41, "timezone": "Asia/Seoul", "refresh": "5s", "editable": False,
        "time": {"from": "now-3m", "to": "now"}, "tags": ["DRYER-SIM-01", "합성 데이터"], "panels": panels,
        "links": [{"type": "link", "title": "전체 운전지표로 돌아가기", "url": "/d/mist-dryer/mist-dryer"}],
        "templating": {"list": [{
            "name": "session", "label": "실행 세션", "type": "query", "datasource": DATASOURCE, "refresh": 2,
            "current": {"text": "현재 실행 세션", "value": "active"},
            "query": """SELECT label AS __text, value AS __value FROM (
                SELECT '현재 실행 세션' AS label, 'active' AS value, NULL::timestamptz AS started_at
                UNION ALL
                SELECT source || ' · ' || to_char(started_at AT TIME ZONE 'Asia/Seoul','MM-DD HH24:MI:SS') ||
                    ' KST · ' || left(session_id::text,8), session_id::text, started_at
                FROM dryer_twin.sessions WHERE equipment_id='DRYER-SIM-01'
            ) AS choices ORDER BY started_at DESC NULLS FIRST""",
        }]},
    }
    path = (output or root / "grafana/dashboards") / "signals.json"
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(dashboard, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

