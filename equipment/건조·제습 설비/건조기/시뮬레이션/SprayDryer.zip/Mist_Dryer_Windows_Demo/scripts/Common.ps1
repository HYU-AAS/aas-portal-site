$ErrorActionPreference = 'Stop'
$Root = (Resolve-Path -LiteralPath (Join-Path $PSScriptRoot '..')).Path
$Runtime = Join-Path $Root '.runtime'
$Python = Join-Path $Root '.venv/Scripts/python.exe'
$Compose = @('--project-directory',$Root,'--env-file',(Join-Path $Root '.env'),'-f',(Join-Path $Root 'compose.yaml'))
function Read-DryerConfig([string]$path = (Join-Path $Root '.env')) {
    $map = @{}
    foreach ($line in Get-Content -LiteralPath $path -Encoding UTF8) {
        if ($line -match '^\s*([^#=]+)=(.*)$') { $map[$Matches[1].Trim()] = $Matches[2] }
    }
    return $map
}
function Dryer-Compose {
    & docker compose @Compose @args
    if ($LASTEXITCODE -ne 0) { throw "Compose failed ($LASTEXITCODE)" }
}
function Wait-DryerHttp([string]$url) {
    $deadline = (Get-Date).AddSeconds(45)
    do {
        try { return Invoke-RestMethod -Uri $url -TimeoutSec 3 }
        catch { Start-Sleep -Milliseconds 450 }
    } while ((Get-Date) -lt $deadline)
    throw "Service did not become ready: $url"
}
function Get-DryerProcess([string]$name) {
    $file = Join-Path $Runtime "$name.pid"
    if (!(Test-Path -LiteralPath $file)) { return }
    $parts = (Get-Content -LiteralPath $file) -split ','
    $process = Get-Process -Id ([int]$parts[0]) -ErrorAction SilentlyContinue
    if ($process -and $parts.Count -eq 2 -and $process.StartTime.ToUniversalTime().Ticks -eq [long]$parts[1]) { return $process }
}
function Set-DryerProcess([string]$name,$process) {
    "$($process.Id),$($process.StartTime.ToUniversalTime().Ticks)" | Set-Content -LiteralPath (Join-Path $Runtime "$name.pid")
}
function Clear-DryerStop([string]$name) {
    $file = Join-Path $Runtime "stop-$name"
    if (Test-Path -LiteralPath $file) { Remove-Item -LiteralPath $file }
}
