param([string]$Python312, [string]$IsaacRoot)
$ErrorActionPreference = 'Stop'
$root = (Resolve-Path -LiteralPath (Join-Path $PSScriptRoot '..')).Path
$runtime = Join-Path $root '.runtime'
New-Item -ItemType Directory -Force $runtime, (Join-Path $root 'reports') | Out-Null
$config = Join-Path $root '.env'
if (!(Test-Path -LiteralPath $config)) {
    $lines = Get-Content -LiteralPath (Join-Path $root '.env.example')
    $lines = foreach ($line in $lines) {
        if ($line -match '^(PG_PASSWORD|READER_PASSWORD|GRAFANA_PASSWORD|INGEST_KEY)=$') {
            $key = $Matches[1]
            $bytes = New-Object byte[] 24
            $rng = [Security.Cryptography.RandomNumberGenerator]::Create()
            try { $rng.GetBytes($bytes) } finally { $rng.Dispose() }
            "$key=$([BitConverter]::ToString($bytes).Replace('-','').ToLowerInvariant())"
        } elseif ($IsaacRoot -and $line.StartsWith('ISAAC_ROOT=')) {
            "ISAAC_ROOT=$($IsaacRoot.Replace('\','/'))"
        } else { $line }
    }
    [IO.File]::WriteAllLines($config, $lines, [Text.UTF8Encoding]::new($false))
}
$python = Join-Path $root '.venv/Scripts/python.exe'
if (!(Test-Path -LiteralPath $python)) {
    $venv = Join-Path $root '.venv'
    if ($Python312) { & $Python312 -m venv $venv } else { & py -3.12 -m venv $venv }
    if ($LASTEXITCODE -ne 0) { throw 'Use -Python312 with the x64 Python 3.12 python.exe path.' }
}
& $python -m pip install -r (Join-Path $root requirements.txt)
if ($LASTEXITCODE -ne 0) { throw 'Runtime dependency installation failed.' }
