import argparse
from datetime import datetime, timezone
import json
import re
import sys
import time
from urllib.error import HTTPError
from urllib.request import Request, urlopen

from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT/"bridge"))
from server import CATALOG, SETTINGS, connect, decode
from basyx import BaSyx, encoded
from kpi import Engine


def fetch(url, body=None):
    data = json.dumps(body).encode() if body is not None else None
    request = Request(url, data=data, headers={"Content-Type":"application/json"})
    with urlopen(request, timeout=5) as response:
        return json.load(response)


def row_print(label, rows):
    print(label, json.dumps(rows, default=str, ensure_ascii=False))


def regressions():
    engine = Engine(CATALOG)
    for spec in CATALOG["kpis"]:
        name = spec["name"]
        original = engine.example(name)
        result, status = engine.evaluate(name, original)
        assert status == "Valid" and abs(result-float(spec["example"])) < 1e-8, (name,status,result)
        absent = dict(original)
        absent.pop(next(iter(absent)))
        assert engine.evaluate(name, absent) == (None,"MissingInput")
    original = engine.example("DefectRate")
    original["QuantityUnit"]["unit"]="kg"
    assert engine.evaluate("DefectRate",original) == (None,"InvalidUnit")
    zero = engine.example("OverallEquipmentEffectiveness")
    zero["OperatingTime"]["value"]="PT0S"
    value, status = engine.evaluate("OverallEquipmentEffectiveness",zero)
    assert value is None and status.startswith("InvalidInput")
    print("Approved AIMC: 19/19 exact regression matches within 1e-8; missing, zero denominator and wrong unit cases passed")


def sample(api):
    def read(path):
        return api.call(api.sm("OperationalData") + "/submodel-elements/" + path)
    for _ in range(20):
        initial = read("TwinRuntime")
        ctx = read("CurrentOperation.JobContext")
        air = read("AirHandlingOperation.AirConditions")
        tail = read("TwinRuntime")
        def fields(collection):
            return {element["idShort"]:element.get("value") for element in collection["value"]}
        context, live = fields(ctx), fields(tail)
        if fields(initial) == live and context["LastUpdateTimestamp"] == live["ObservedAt"]:
            return live, context, fields(air)
        time.sleep(.15)
    raise RuntimeError("Could not obtain coherent BaSyx observations")


def correlate(api, db, sid):
    for _ in range(18):
        live, ctx, air = sample(api)
        at = ctx["LastUpdateTimestamp"]
        if at:
            rows = db.execute("""SELECT m.seq,m.kind,m.batch_id,m.observed_at,m.sim_seconds,o.payload->'values' AS values,
                                      o.applied_at FROM messages m JOIN aas_outbox o USING(session_id,seq)
                                  WHERE m.session_id=%s AND m.seq=%s AND m.observed_at=%s AND m.batch_id=%s""",
                              (sid, int(live["Sequence"]), at, ctx["BatchId"])).fetchall()
            for row in rows:
                vals = row["values"]
                names = ("InletAirTemperatureActual","InletAirTemperatureSetpointActual","OutletAirTemperatureActual")
                if all(abs(float(air[name])-vals[name]) < .001 for name in names):
                    assert str(ctx["OperatingState"]).lower() == str(vals["OperatingState"]).lower()
                    row["gui_api"]={key:air[key] for key in names}
                    row["gui_api"].update(batch=ctx["BatchId"], observed_at=at, progress=ctx["ProcessProgressRate"])
                    return row
        time.sleep(.3)
    raise AssertionError("Could not correlate the AAS snapshot with recorded history")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--status",action="store_true")
    parser.add_argument("--batches",type=int,default=2)
    args=parser.parse_args()
    sys.stdout.reconfigure(encoding="utf-8")
    api = BaSyx(ROOT,SETTINGS,CATALOG)
    base = f"http://127.0.0.1:{SETTINGS['GRAFANA_PORT']}"
    with connect(reader=True) as db:
        active=db.execute("SELECT s.* FROM active_session a JOIN sessions s USING(session_id)").fetchone()
        row_print("Active session:",active)
        if args.status:
            return
        assert active and active["source"]=="isaac_sim", "An Isaac Sim session is required"
        sid=active["session_id"]
        shell=api.call("/shells/"+encoded(CATALOG["shell"]))
        assert len(shell["submodels"])==8
        batch=db.execute("""SELECT batch_id,started_at,completed_at,duration_sim_seconds FROM batch_runs
                            WHERE session_id=%s AND completed_at IS NOT NULL ORDER BY completed_at""",(sid,)).fetchall()
        assert len(batch)>=args.batches, "Wait for the required number of completed batches"
        mode = db.execute("SELECT payload->>'process_mode' AS mode FROM messages WHERE session_id=%s AND seq=0",
                          (sid,)).fetchone()["mode"]
        duration = CATALOG["stages"][1][1] if mode == "continuous_spray" else sum(s[1] for s in CATALOG["stages"])
        assert all(row["duration_sim_seconds"] == duration for row in batch)
        phases=db.execute("""SELECT batch_id,array_agg(phase ORDER BY seq) AS phases
                        FROM process_events WHERE session_id=%s AND kind='phase_enter'
                        GROUP BY batch_id ORDER BY batch_id""",(sid,)).fetchall()
        if mode == "continuous_spray":
            transitions = db.execute("""SELECT phase FROM process_events WHERE session_id=%s AND kind='phase_enter'
                                      ORDER BY seq""", (sid,)).fetchall()
            assert [row["phase"] for row in transitions][:2] == ["Preheat", "Dry"]
            assert sum(row["phase"] == "Preheat" for row in transitions) == 1
        else:
            assert all(next(item for item in phases if item["batch_id"]==row["batch_id"])["phases"]==["Preheat","Dry","Cool"] for row in batch)
        row_print("Completed:",batch[-2:])
        row_print("Phase transitions:",phases[-3:])
        first=correlate(api,db,sid)
        second=first
        for _ in range(15):
            time.sleep(.55)
            second=correlate(api,db,sid)
            if first["observed_at"] != second["observed_at"]:
                break
        assert first["observed_at"] != second["observed_at"], "Expected changing live observations"
        row_print("Cross-system first:",first)
        row_print("Cross-system second:",second)
        log_entries=[json.loads(line) for line in (ROOT/"reports/isaac-messages.log").read_text(encoding="utf-8").splitlines()]
        assert any(row["session_id"]==str(sid) and row["seq"]==first["seq"] for row in log_entries)
        times=db.execute("""WITH samples AS (SELECT observed_at,ingested_at,
           extract(epoch from observed_at-lag(observed_at) OVER (ORDER BY seq)) AS cadence FROM telemetry WHERE session_id=%s)
           SELECT count(*),round(avg(cadence),3) AS average_period_s,round(min(cadence),3) AS min_period_s,
           round(max(cadence),3) AS max_period_s,round(avg(extract(epoch from ingested_at-observed_at)),3) AS average_db_lag_s
           FROM samples""",(sid,)).fetchone()
        row_print("Cadences:",times)
        rows=db.execute("SELECT period,count(*) AS rows,count(value) AS valid FROM kpi_results WHERE session_id=%s GROUP BY period",(sid,)).fetchall()
        row_print("KPI DB windows:",rows)
        record=api.call(api.sm("TimeSeries")+"/submodel-elements/Segments.InternalSegmentKPI.Records.KPIRecord")
        fields={item["idShort"]:item.get("value") for item in record["value"]}
        group=fields["AggregationKey"]
        kpis=db.execute("SELECT kpi,value,status FROM kpi_results WHERE session_id=%s AND aggregation_key=%s",(sid,group)).fetchall()
        assert kpis and all(fields[row["kpi"]+"Status"]==row["status"] and
                            (row["value"] is None or abs(float(fields[row["kpi"]])-row["value"])<1e-8) for row in kpis)
        row_print("KPI TimeSeries match:",{"key":group,"time01":fields["Time01"],"results":kpis})
        queries=(ROOT/"db/queries.sql").read_text(encoding="utf-8")
        for query in queries.split(";"):
            if query.strip():
                rows=db.execute(query).fetchall()
                print("Read-only SQL rows:",len(rows))
        try:
            db.execute("UPDATE dryer_twin.telemetry SET progress=0 WHERE false")
            raise AssertionError("Read-only user unexpectedly has UPDATE access")
        except Exception as error:
            assert getattr(error,"sqlstate",None) in ("25006","42501")
    dashboard=fetch(base+"/api/dashboards/uid/mist-dryer")["dashboard"]
    trend=next(p for p in dashboard["panels"] if p["id"]==7)["targets"][0]
    query={**trend,"rawSql":trend["rawSql"].replace("${session:sqlstring}",f"'{sid}'"),
           "intervalMs":1000,"maxDataPoints":500}
    now=int(time.time()*1000)
    result=fetch(base+"/api/ds/query",{"queries":[query],"from":str(now-900000),"to":str(now)})
    assert result["results"]["A"]["frames"],result
    live = next(p for p in dashboard["panels"] if p["id"]==5)["targets"][0]
    result=fetch(base+"/api/ds/query",{"queries":[live],"from":str(now-900000),"to":str(now)})
    assert result["results"]["A"]["frames"][0]["data"]["values"] == [["실시간 수신"]], result
    print(f"Grafana viewer query HTTP 200, refresh {dashboard['refresh']}, session {sid}")
    regressions()


if __name__=="__main__":
    main()

