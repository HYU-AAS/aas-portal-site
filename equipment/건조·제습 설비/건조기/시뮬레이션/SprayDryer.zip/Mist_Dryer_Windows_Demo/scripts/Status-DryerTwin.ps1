. (Join-Path $PSScriptRoot Common.ps1)
$cfg = Read-DryerConfig
Dryer-Compose ps -a
foreach ($name in 'isaac','bridge') {
    $process=Get-DryerProcess $name
    if ($process) { Write-Output "$name PID $($process.Id)" } else { Write-Output "$name stopped" }
}
& $Python (Join-Path $Root 'scripts/smoke.py') --status
