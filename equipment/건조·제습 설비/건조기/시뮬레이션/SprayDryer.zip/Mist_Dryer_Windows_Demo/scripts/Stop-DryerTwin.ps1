param([switch]$KeepServices)
. (Join-Path $PSScriptRoot Common.ps1)
function Stop-LoggedProcess([string]$name) {
    $process = Get-DryerProcess $name
    if ($process) {
        New-Item -ItemType File -Force -Path (Join-Path $Runtime "stop-$name") | Out-Null
        if (!$process.WaitForExit(20000)) { throw "$name is still shutting down. Inspect its project log and run Stop again." }
    }
}
Stop-LoggedProcess isaac
if (!$KeepServices) {
    Stop-LoggedProcess bridge
    Dryer-Compose stop
}
