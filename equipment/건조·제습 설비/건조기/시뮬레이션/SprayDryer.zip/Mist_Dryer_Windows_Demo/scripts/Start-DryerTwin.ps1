param([switch]$ServicesOnly, [switch]$CheckKit, [string]$EquipmentEnv, [ValidateRange(1,1000000)][int]$Batches)
. (Join-Path $PSScriptRoot Common.ps1)
if (!(Test-Path -LiteralPath $Python)) { throw 'Run Initialize-DryerTwin.ps1 first.' }
if ($EquipmentEnv -and $ServicesOnly) { throw 'Use either -EquipmentEnv or -ServicesOnly.' }
if ($Batches -and ($ServicesOnly -or (Get-DryerProcess isaac))) {
    throw 'Stop the current Isaac Sim session before starting a finite-batch run.'
}
$cfg = if ($EquipmentEnv) { Read-DryerConfig (Resolve-Path -LiteralPath $EquipmentEnv).Path } else { Read-DryerConfig }
$launcher = Join-Path $cfg.ISAAC_ROOT 'python.bat'
if (!$ServicesOnly -and !(Test-Path -LiteralPath $launcher)) { throw 'Set ISAAC_ROOT in .env to the installed Workstation directory.' }
foreach ($model in @('runtime.json','environment.json','Mist_Dryer_DRYER-SIM-01.aasx')) {
    if (!(Test-Path -LiteralPath (Join-Path $Root "aas/$model"))) { throw "Missing aas/$model. Extract the full demo ZIP." }
}
if ($EquipmentEnv) {
    if ($cfg.AAS_URL -notmatch '^https://' -or $cfg.ARCHIVE_URL -notmatch '^https://' -or !$cfg.AAS_TOKEN) {
        throw 'Set HTTPS AAS_URL, HTTPS ARCHIVE_URL and AAS_TOKEN in the equipment file.'
    }
    if (Get-DryerProcess isaac) { throw 'Stop the current Isaac Sim session before switching servers.' }
}
if (!$EquipmentEnv) {
    $viewerPort = if ($cfg.VIEWER_PORT) { $cfg.VIEWER_PORT } else { '8092' }
    & $Python (Join-Path $Root 'grafana/build_dashboard.py') $cfg.AAS_UI_PORT --viewer "http://127.0.0.1:$viewerPort/"
    if ($LASTEXITCODE) { throw 'Dashboard generation failed.' }
    if (Get-DryerProcess bridge) {
        $running = Get-DryerProcess bridge
        New-Item -ItemType File -Force -Path (Join-Path $Runtime 'stop-bridge') | Out-Null
        if (!$running.WaitForExit(20000)) { throw 'The archive process is still shutting down.' }
    }
    Dryer-Compose up -d --remove-orphans
    Dryer-Compose wait aas-init
    Dryer-Compose exec -T db psql -v ON_ERROR_STOP=1 -U dryer_owner -d mist_dryer -f /docker-entrypoint-initdb.d/02-schema.sql -f /docker-entrypoint-initdb.d/03-kpi-revision.sql | Out-Null
    $api = "http://127.0.0.1:$($cfg.AAS_PORT)"
    $grafana = "http://127.0.0.1:$($cfg.GRAFANA_PORT)"
    $bridgeUri = "http://127.0.0.1:$($cfg.BRIDGE_PORT)"
    $null = Wait-DryerHttp "$api/description"
    $null = Wait-DryerHttp "$grafana/api/health"
    $null = Wait-DryerHttp "http://127.0.0.1:$($cfg.AAS_UI_PORT)/"
    $result = Wait-DryerHttp "$api/shells"
    if ('MistDryerSim01' -notin $result.result.idShort) { throw 'Expected shell was not imported. Inspect docker compose logs aas-init.' }
    if (!(Get-DryerProcess bridge)) {
        Clear-DryerStop bridge
        $bridge = Start-Process $Python -ArgumentList '-u bridge/server.py' -WorkingDirectory $Root -WindowStyle Hidden -PassThru `
           -RedirectStandardOutput (Join-Path $Root 'reports/bridge-out.log') -RedirectStandardError (Join-Path $Root 'reports/bridge.log')
        Set-DryerProcess bridge $bridge
    }
    $null = Wait-DryerHttp "$bridgeUri/health"
}
if ($CheckKit) {
    Start-Process (Join-Path $cfg.ISAAC_ROOT 'isaac-sim.compatibility_check.bat') -WorkingDirectory $cfg.ISAAC_ROOT -WindowStyle Normal
}
if (!$ServicesOnly -and !(Get-DryerProcess isaac)) {
    Clear-DryerStop isaac
    $script = Join-Path $Root 'isaac/run_dryer.py'
    $cmd = '/d /s /c ""' + $launcher + '" "' + $script + '" --/crashreporter/enabled=false --/app/window/maximized=false"'
    $previous = $env:MIST_DRYER_ENV
    $previousBatchOverride = $env:MIST_DRYER_BATCHES
    try {
        $env:MIST_DRYER_ENV = if ($EquipmentEnv) { (Resolve-Path -LiteralPath $EquipmentEnv).Path } else { Join-Path $Root '.env' }
        if ($Batches) { $env:MIST_DRYER_BATCHES = [string]$Batches }
        $app = Start-Process cmd.exe -ArgumentList $cmd -WorkingDirectory $cfg.ISAAC_ROOT -WindowStyle Hidden -PassThru `
           -RedirectStandardOutput (Join-Path $Root 'reports/isaac-stdout.log') -RedirectStandardError (Join-Path $Root 'reports/isaac-stderr.log')
    } finally {
        $env:MIST_DRYER_ENV = $previous
        $env:MIST_DRYER_BATCHES = $previousBatchOverride
    }
    Set-DryerProcess isaac $app
}
if ($EquipmentEnv) {
    Write-Output "AAS $($cfg.AAS_URL)"
} else {
    Write-Output "Grafana  $grafana/d/mist-dryer/mist-dryer"
    Write-Output "BaSyx UI http://127.0.0.1:$($cfg.AAS_UI_PORT)"
    Write-Output "API      $api/swagger-ui/index.html"
    Write-Output "3D       http://127.0.0.1:$viewerPort/"
}
